# Delta Test Pipeline Deploy

This repository is to be used by app squad teams to deploy testing pipelines from the hub (tooling account) to spoke accounts.

## Table of Contents

[[_TOC_]]

## Architecture

![Architecture Diagram](.images/architecture.png)

1. The tooling account deployment pipeline is deployed to configure the testing pipeline.
2. The test pipeline is created in the target account.
3. The application pipeline triggers the testing pipeline.
4. Test results are stored in the tooling account S3 bucket.

## Prerequisites

### AWS Accounts

App Squad Teams will need to have:

- 1 Tooling Account ID with access to the `DevToolsUser` Role (Access can be granted via [SailPoint](iam.delta.com))
- List of AWS Spoke Account IDs that require configuration (ex: Dev/SI/PRD/Air4 SI/Air4 Prod)

### Pre-Installed Tools

It is highly recommended to install this pattern in the [AWS CloudShell](https://aws.amazon.com/cloudshell/). At minimum the following tools need to be installed on the local workstation:

- zip/unzip
- aws cli (v2.0+)
- make (Makefile)

### Pre-Configuration

>NOTE: The following configuration must completed prior to continuing:

- [S3 bucket deployment](https://git.delta.com/ccoe/aws/tooling-account/delta-s3-enterprise-buckets#step-2-deploy-s3-buckets-in-tooling-account)
- [SSM Parameters populated](https://git.delta.com/ccoe/aws/tooling-account/delta-s3-enterprise-buckets#step-3-deploy-ssm-parameters-to-cross-accounts)
- [Git Custom Action](https://git.delta.com/ccoe/aws/codepipeline-custom-actions/delta-git-clone/codepipeline-custom-action#step-3-deploy-custom-action-to-cross-accounts) (If sourcing from Git)
- [Nexus Custom Action](https://git.delta.com/ccoe/aws/codepipeline-custom-actions/nexus/fetch-raw-hosted-artifact#step-3-deploy-custom-action-to-cross-accounts) (If sourcing from Nexus)

## Installation

### Step 1: Fork Repository and update parameter/tags files

1. Login to the AWS Tooling Account using sso credentials.
2. Warmup Cloudshell by clicking this [Cloudshell](https://console.aws.amazon.com/cloudshell/) or go to AWS services-->Cloudshell.
3. Download the latest version of this repository
4. Update parameter/tags files

   - `pipelines/functional-test-pipeline/config.json` - Parameters for the CloudFormation template (See Parameters Table).
   - `pipelines/functional-test-pipeline/tags.json` - List of tags for the resources created by the CloudFormation Template.

5. Zip the updated artifact
6. In the Actions button of the AWS cloudshell, use Upload File option to upload the above downloaded zip artifact.
7. Unzip the artifact which will be available at home directory on cloudshell
8. Navigate into the newly uploaded directory before proceeding



| Parameter | Description |
|-------------|------------ |
| TestPipelineName | Name of the test pipeline |
| GitUrl | URL of the repository containing test pipeline configuration |
| GitRevision | Branch for the GitUrl repository |
| GitAuthenticationSecretName | Name of the AWS Secret for basic authentication |
| GitAuthenticationSecretType | The type of authentication |
| TargetAccountId | SSM Parameter Name containing target account ID |
| CfnTemplateConfiguration | The parameter files for the test pipeline CFT |
| CfnTemplatePath | Path to the test pipeline template |
| CfnCapabilities | IAM Capabilities needed for the test pipeline CFT |

### Step 2: Create Deployment Pipeline in the Tooling Account

```BASH
make build
```

### Step 3: Validating Installation

1. Ensure the CloudFormation stacks complete successfully
2. Log into the Tooling account. Ensure the resources are deployed into the tooling account
3. Log into the spoke accounts. Ensure the resources are deployed into the spoke accounts

### Updating a Stack in Tooling

There may be a use case that you need to modify the configuration or add aditional tags to the created resources. You can always update the [parameter files](config/) and perform the following commands to update the stacks.

```BASH
## Update stack in tooling account
make update
```

>NOTE: If updates are made to the deployment pipeline in tooling or if you have updated your test code, you will need to re-release the deployment pipeline in tooling which updates the test pipeline in the target account.

## Uninstall

### Step 1: Uninstall Resources in Spoke Accounts

1. From the deployment pipeline in the Tooling account, press review and then approve the RollBackApproval stage. This will roll back the CFT deployed into the target accounts, thus removing those resources.

### Step 2: Uninstall CloudFormation Stacks in Tooling Account

```BASH
make clean
```
