package com.documentmanagement.Pojo.WIFI;
public class AirportRadiusMileCnt{
    public String unitOfMeasure;
    public int unitOfMeasureCnt;
}
