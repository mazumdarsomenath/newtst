package com.documentmanagement.Pojo.WIFI;
public class Tax{
    public TaxAmt taxAmt;
    public Object taxCode;
    public Object taxChargeTypeCode;
}
