package com.documentmanagement.Pojo.WIFI;
public class TotalTaxAmt{
    public CurrencyEquivalentPrice currencyEquivalentPrice;
    public MilesEquivalentPrice milesEquivalentPrice;
}
