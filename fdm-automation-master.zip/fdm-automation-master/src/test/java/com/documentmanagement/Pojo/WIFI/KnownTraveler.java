package com.documentmanagement.Pojo.WIFI;
public class KnownTraveler{
    public Object knownTravelerNum;
    public Object programName;
    public String countryCode;
}
