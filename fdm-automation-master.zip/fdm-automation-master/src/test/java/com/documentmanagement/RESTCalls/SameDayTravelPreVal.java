package com.documentmanagement.RESTCalls;

import com.documentmanagement.GenericMethods.GenericMethods;
import com.documentmanagement.PageObjecs.AdminTool;
import com.documentmanagement.handlers.ReadProperties;
import io.restassured.RestAssured;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.io.File;

import static io.restassured.RestAssured.given;

public class SameDayTravelPreVal {

    DocProduceWIFI docPrd = new DocProduceWIFI();
    GenericMethods gm = new GenericMethods();


    HashMap<String, String> ResMapList = ReadProperties
            .getAllValue(".\\src\\main\\resources\\Configuration.properties");
    private String jsonBody;
    private String newFilePath;

    public String reasonForIssuanceSubCode() throws Exception {
        String reasonForIssuanceSubCodeVal = null;
        try {
            String file = ResMapList.get("samedaytravelprevalJson");
            String json = docPrd.readFileAsString(file);
            JSONObject obj = new JSONObject(json);
            JSONObject val1 = new JSONObject(obj.get("order").toString());
            JSONArray orderItemsJSON = new JSONArray(val1.get("orderItems").toString());
            JSONObject orderItemsJSONIndex = new JSONObject(orderItemsJSON.get(0).toString());
            JSONArray retailItemsJson = new JSONArray(orderItemsJSONIndex.get("retailItems").toString());
            JSONObject retailItemsJsonIndex = new JSONObject(retailItemsJson.get(0).toString());
            JSONObject retailItemMetaDataJson = new JSONObject(retailItemsJsonIndex.get("retailItemMetaData").toString());
            JSONObject productInformationJson = new JSONObject(retailItemMetaDataJson.get("productInformation").toString());
            reasonForIssuanceSubCodeVal = (productInformationJson.get("reasonForIssuanceSubCode").toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return reasonForIssuanceSubCodeVal;
    }

    public String getsamedaytravelresp(String file_path) {
        // String inputString;
        String res = null;
        try {
            //String file = ResMapList.get("pathtodocproducewifitext");
            String json = docPrd.readFileAsString(file_path);

            RestAssured.baseURI = ResMapList.get("samedaytravelpreval");
            RestAssured.useRelaxedHTTPSValidation();
            res = given().log().all().header("Accept", "application/json")
                    .header("Content-Type", "application/json")
                    .header("TransactionId", "123457570-374747-3333")
                    .header("appId", "AX")
                    .header("channelId", "AXS")
                    .body(json)
                    .post(ResMapList.get("samedaytravelpreval"))
                    .then()
                    .statusCode(200)
                    .extract()
                    .response().getBody().asString();


        } catch (JSONException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }

    public void getvalerrormes(String resBody, String expectedValue) throws JSONException {
        String messageText = null;
        JSONObject val2 = null;
        try {
            JSONObject obj = new JSONObject(resBody);
            JSONArray val = (JSONArray) obj.get("orderItemSummaries");
            JSONObject errVal = new JSONObject(val.get(0).toString());
            JSONArray val1 = (JSONArray) errVal.get("orderItems");
            JSONObject errVal1 = new JSONObject(val1.get(0).toString());
            JSONArray retailItems = (JSONArray) (errVal1.get("preValidatedRetailItems"));
            if (retailItems.length() > 1) {
                val2 = new JSONObject(retailItems.get(4).toString());
            } else {
                val2 = new JSONObject(retailItems.get(0).toString());
            }
            messageText = val2.get("validationError").toString().split(":")[1].split(",")[0].replace("\"", "");

            //String messageText = val3;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Assert.assertEquals("!!!Error!!!, Error message not displaying as expected", messageText, expectedValue);
    }

    public void getvalerrormesg(String resBody, String expectedValue) throws JSONException {
        String messageText = null;
        JSONObject val2;
        try {
            JSONObject obj = new JSONObject(resBody);
            JSONArray val = (JSONArray) obj.get("orderItemSummaries");
            JSONObject errVal = new JSONObject(val.get(0).toString());
            JSONArray val1 = (JSONArray) errVal.get("orderItems");
            JSONObject errVal1 = new JSONObject(val1.get(0).toString());
            JSONArray retailItems = (JSONArray) (errVal1.get("preValidatedRetailItems"));

            if (retailItems.length() > 3) {
                val2 = new JSONObject(retailItems.get(4).toString());
            } else {
                val2 = new JSONObject(retailItems.get(0).toString());
            }
            messageText = val2.get("validationError").toString().split(":")[1].split(",")[0].replace("\"", "");

            //String messageText = val3;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Assert.assertEquals("!!!Error!!!, Error message not displaying as expected", messageText, expectedValue);
    }

    public void getvalmes(String resBody, String expectedValue, String keyName) throws JSONException {
        String messageText = null;
        try {
            JSONObject obj = new JSONObject(resBody);
            JSONArray val = (JSONArray) obj.get("orderItemSummaries");
            JSONObject errVal = new JSONObject(val.get(0).toString());
            JSONArray val1 = (JSONArray) errVal.get("orderItems");
            JSONObject errVal1 = new JSONObject(val1.get(0).toString());
            JSONArray retailItems = (JSONArray) (errVal1.get("preValidatedRetailItems"));
            JSONObject val2 = new JSONObject(retailItems.get(0).toString());
            messageText = val2.get(keyName).toString();

            //String messageText = val3;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Assert.assertEquals("!!!Error!!!, Error message not displaying as expected", messageText, expectedValue);
    }

    public static String readFileAsString(String file) throws Exception {
        return new String(Files.readAllBytes(Paths.get(file)));
    }

    public WebDriver setJSONDocprdsdt(String jsonBody) {
        this.jsonBody = jsonBody;
//        @SuppressWarnings("deprecation")
        WebDriver driver = null;
        try {
            String file = ResMapList.get(jsonBody);
            String json = readFileAsString(file);
            JSONObject obj = new JSONObject(json);
            JSONObject val1 = new JSONObject(obj.get("order").toString());
            JSONObject val2 = new JSONObject(val1.get("orderDataList").toString());
            JSONArray val3 = new JSONArray(val2.get("customers").toString());
            JSONObject val4 = new JSONObject(val3.get(0).toString());
            JSONObject firstNameJson = new JSONObject(val4.get("personName").toString());
            String firstNameJsonVal = (firstNameJson.get("firstName").toString());
            String lastNameJsonVal = (firstNameJson.get("lastName").toString());
            String firstname = firstNameJsonVal;
            String lastname = lastNameJsonVal;

            driver = gm.launchEMD_plus();
//            Webdriver driver = null;
            AdminTool ad = new AdminTool();
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MMM-yy");
            LocalDateTime now = LocalDateTime.now();
            String today_date = dtf.format(now);
            ad.click_lastnamecheck();
            ad.enter_lastname(lastname);
            ad.enter_issuedaterange(today_date);
            ad.enter_issuedaterange1(today_date);
            ad.click_find();

            ad.find_pax_names(firstname, lastname);

            Thread.sleep(3000);

            String passname = ad.getPassengerName();
            String docnum = ad.getDocumentNumber();
            gm.writeExcel(passname, docnum);

            Thread.sleep(3000);
            ad.click_coupon_details();
        } catch (JSONException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return driver;
    }

    public void writeExcel(String ticket_number) {
        try {
            FileInputStream file = new FileInputStream(new File(ResMapList.get("pathToWrXLSDTDocIssuanceRes")));
            XSSFWorkbook wb = new XSSFWorkbook(file);
            XSSFSheet sheet = wb.getSheetAt(0);
            //Row r = sheet.createRow(1);
            for (int i = sheet.getLastRowNum(); i <= sheet.getLastRowNum() + 1; i++) {
                //if (sheet.getRow(i+1) == null) {
                // This cell is empty
                Row r = sheet.createRow(i + 1);
//    					r.createCell(0).setCellValue(passenger_name);
//    					r.createCell(1).setCellValue(document_number);
                r.createCell(0).setCellValue(ticket_number);
                //}
                break;
            }
            FileOutputStream outFile = new FileOutputStream(new File(ResMapList.get("pathToWrXLSDTDocIssuanceRes")));
            wb.write(outFile);
            file.close();
            System.out.println("Your excel file has been generated!");

        } catch (Exception ex) {
            System.out.println(ex);
        }

    }

    public void getvalorderitems(String resBody, String keyName, String expectedValue) throws JSONException {
        String val1 = null;

        try {
            JSONObject obj = new JSONObject(resBody);
            JSONArray val = (JSONArray) obj.get("orderItemSummaries");
            JSONObject errVal = new JSONObject(val.get(0).toString());
            val1 = (errVal.get(keyName)).toString();

            //String messageText = val3;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Assert.assertEquals("!!!Does Not Match", val1, expectedValue);
    }



}