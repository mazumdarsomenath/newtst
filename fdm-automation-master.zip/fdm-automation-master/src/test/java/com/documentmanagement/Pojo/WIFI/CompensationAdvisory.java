package com.documentmanagement.Pojo.WIFI;
import java.util.List; 
public class CompensationAdvisory{
    public Object code;
    public Object message;
    public List<MoreInfo> moreInfo;
}
