package com.documentmanagement.Pojo.WIFI;
public class RetailItemPricing{
    public String pricingOptionId;
    public TotalAmt totalAmt;
    public BaseAmt baseAmt;
}
