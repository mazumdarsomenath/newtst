package com.documentmanagement.Pojo.WIFI;

import java.util.Date;

public class FlightLegArrivalDepartureStatus{
    public Date actualArrivalLocalTs;
    public Date actualArrivalUtcTs;
    public Date actualDepartureLocalTs;
    public Date actualDepartureUtcTs;
    public Date actualOutLocalTs;
    public Date actualOutUtcTs;
    public String arrivalStateCode;
    public String departureStateCode;
    public String arrivalStateCodeDesc;
    public String departureStateCodeDesc;
    public Date estimatedArrivalLocalTs;
    public Date estimatedArrivalUtcTs;
    public Date estimatedDepartureLocalTs;
    public Date estimatedDepartureUtcTs;
    public Object inFlightDurationTime;
    public Object notificationAvailabilityText;
    public Object remainingInFlightDurationTime;
    public Date scheduledArrivalLocalTs;
    public Date scheduledArrivalUtcTs;
    public Date scheduledDepartureLocalTs;
    public Date scheduledDepartureUtcTs;
    public Object scheduledFlightLegDurationTime;
    public Object statusColorCode;
    public Object statusDesc;
}
