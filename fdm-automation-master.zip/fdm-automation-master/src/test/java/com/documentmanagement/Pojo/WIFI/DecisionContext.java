package com.documentmanagement.Pojo.WIFI;
public class DecisionContext{
    public Object travelContext;
    public Object decisionCode;
    public Object decisionDesc;
    public Object compensationType;
}
