package com.documentmanagement.Pojo.WIFI;
import java.util.List; 
public class DestinationAirport{
    public String airportCode;
    public String airportName;
    public AirportRadiusMileCnt airportRadiusMileCnt;
    public List<AirportTerminal> airportTerminals;
    public String cityName;
    public String countryCode;
    public String countrySubdivisionCode;
    public String icaoAirportCode;
    public GeographicCoordinate geographicCoordinate;
    public String timeZoneDesc;
}
