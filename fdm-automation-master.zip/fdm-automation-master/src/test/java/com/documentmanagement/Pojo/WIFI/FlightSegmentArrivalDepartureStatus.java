package com.documentmanagement.Pojo.WIFI;

import java.util.Date;

public class FlightSegmentArrivalDepartureStatus{
    public Date actualArrivalLocalTs;
    public Date actualDepartureLocalTs;
    public String actualInLocalTime;
    public Object actualOffLocalTime;
    public Object actualOnLocalTime;
    public Object actualOutLocalTime;
    public String arrivalStateCode;
    public String departureStateCode;
    public String arrivalStateCodeDesc;
    public String departureStateCodeDesc;
    public Object estimatedArrivalLocalTime;
    public Date estimatedArrivalLocalTs;
    public Object estimatedDepartureLocalTime;
    public Date estimatedDepartureLocalTs;
    public String flightCanceledCode;
    public Object notificationAvailabilityText;
    public Date scheduledArrivalLocalTs;
    public Date scheduledDepartureLocalTs;
    public Object scheduledFlightSegmentDurationTime;
    public Object statusColorCode;
    public Object statusDesc;
}
