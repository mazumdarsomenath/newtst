package com.documentmanagement.RESTCalls;

import com.documentmanagement.GenericMethods.GenericMethods;
import com.documentmanagement.handlers.ReadProperties;
import io.restassured.RestAssured;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;

import static io.restassured.RestAssured.given;

public class DocProduceWIFI {
    HashMap<String, String> ResMapList = ReadProperties
            .getAllValue(".\\src\\main\\resources\\Configuration.properties");
    GenericMethods gm = new GenericMethods();


    public void setJSONDocprdwifiFromExcel(int ind, String jsonPath, String MKD_PRD_CD, String MKD_PRD_NM, String MKD_PRD_DS, String MKD_PRD_TYP_CD, String EMD_RFIC_CD, String newFilePath) throws Exception {
//        @SuppressWarnings("deprecation")
//        PersonName employee = new PersonName(firstName, LastName);
        try {
            String file = ResMapList.get(jsonPath);
            String json = readFileAsString(file);
            JSONObject obj = new JSONObject(json);
            JSONObject val1 = new JSONObject(obj.get("order").toString());
            JSONArray orderItemsJSON = new JSONArray(val1.get("orderItems").toString());
            JSONObject orderItemsJSONIndex = new JSONObject(orderItemsJSON.get(0).toString());
            JSONArray retailItemsJson = new JSONArray(orderItemsJSONIndex.get("retailItems").toString());
            JSONObject retailItemsJsonIndex = new JSONObject(retailItemsJson.get(ind).toString());
            JSONObject retailItemMetaDataJson = new JSONObject(retailItemsJsonIndex.get("retailItemMetaData").toString());
            JSONObject productInformationJson = new JSONObject(retailItemMetaDataJson.get("productInformation").toString());


            String productId = (productInformationJson.get("productId").toString());
            String ProductName = (productInformationJson.get("productName").toString());
            String ProductDec = (productInformationJson.get("productDesc").toString());
            String RFIC = (productInformationJson.get("reasonForIssuanceCode").toString());
            String ProductSubCategoryCode = (productInformationJson.get("productSubCategoryName").toString());
            String MPTC = (productInformationJson.get("marketedProductTypeCode").toString());

// Updating Json text file
            gm.readTextFile(productId, MKD_PRD_CD, newFilePath);
            gm.readTextFile(ProductName, MKD_PRD_NM, newFilePath);
            gm.readTextFile(ProductDec, MKD_PRD_DS, newFilePath);
            gm.readTextFile(RFIC, EMD_RFIC_CD, newFilePath);
            gm.readTextFile(MPTC, MKD_PRD_TYP_CD, newFilePath);
            gm.readTextFile(ProductSubCategoryCode, MKD_PRD_DS, newFilePath);
        } catch (JSONException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void setJSONDocprdwifi(String jsonBody, String prival, String firstName, String LastName, String newFilePath) throws Exception {
//        @SuppressWarnings("deprecation")
        try {
            String file = ResMapList.get(jsonBody);
            String json = readFileAsString(file);
            JSONObject obj = new JSONObject(json);
            JSONObject val1 = new JSONObject(obj.get("order").toString());
            JSONArray priJSON = new JSONArray(val1.get("formsOfPayment").toString());
            JSONObject priJsonIndex = new JSONObject(priJSON.get(0).toString());
            JSONObject val2 = new JSONObject(val1.get("orderDataList").toString());
            JSONArray val3 = new JSONArray(val2.get("customers").toString());
            JSONObject val4 = new JSONObject(val3.get(0).toString());
            JSONObject firstNameJson = new JSONObject(val4.get("personName").toString());
            String firstNameJsonVal = (firstNameJson.get("firstName").toString());
            String lastNameJsonVal = (firstNameJson.get("lastName").toString());
            //String emailAdr = val4.get("emailAdr").toString();
            String priVal = priJsonIndex.get("paymentReferenceId").toString();

// Updating Json text file
            // gm.readTextFile(emailAdr, emailadd, newFilePath);
            gm.readTextFile(firstNameJsonVal, firstName, newFilePath);
            gm.readTextFile(lastNameJsonVal, LastName, newFilePath);
            if (prival != "nil") {
                gm.readTextFile(priVal, prival, newFilePath);
            }
        } catch (JSONException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void setJSONDocprdwifitwopax(String firstName, String LastName, String secondName, String secondLastName, String newFilePath) throws Exception {
//        @SuppressWarnings("deprecation")
        try {
            String file = ResMapList.get("pathToDocProduceWIFIJsontwopax");
            String json = readFileAsString(file);
            JSONObject obj = new JSONObject(json);
            JSONObject val1 = new JSONObject(obj.get("order").toString());
            JSONArray priJSON = new JSONArray(val1.get("formsOfPayment").toString());
            JSONObject priJsonIndex = new JSONObject(priJSON.get(0).toString());
            JSONObject val2 = new JSONObject(val1.get("orderDataList").toString());
            JSONArray val3 = new JSONArray(val2.get("customers").toString());

            //first value
            JSONObject val4 = new JSONObject(val3.get(0).toString());
            JSONObject firstNameJson = new JSONObject(val4.get("personName").toString());
            String firstNameJsonVal = (firstNameJson.get("firstName").toString());
            String lastNameJsonVal = (firstNameJson.get("lastName").toString());

// Updating Json text file
            gm.readTextFile(firstNameJsonVal, firstName, newFilePath);
            gm.readTextFile(lastNameJsonVal, LastName, newFilePath);


            //second value
            JSONObject val4_1 = new JSONObject(val3.get(1).toString());
            JSONObject firstNameJson_1 = new JSONObject(val4_1.get("personName").toString());
            String firstNameJsonVal1 = (firstNameJson_1.get("firstName").toString());
            String lastNameJsonVal1 = (firstNameJson_1.get("lastName").toString());

// Updating Json text file
            gm.readTextFile(firstNameJsonVal1, secondName, newFilePath);
            gm.readTextFile(lastNameJsonVal1, secondLastName, newFilePath);

        } catch (JSONException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static String readFileAsString(String file) throws Exception {
        return new String(Files.readAllBytes(Paths.get(file)));
    }

    public String getResponse(String file_path, String endPointURL) {
        String res = null;
        try {
            String file = ResMapList.get(file_path);
            String json = readFileAsString(file);

            RestAssured.baseURI = ResMapList.get(endPointURL);
            RestAssured.useRelaxedHTTPSValidation();
            res = given().log().all().header("Accept", "application/json")
                    .header("Content-Type", "application/json")
                    .header("TransactionId", gm.getUUID())
                    .header("appId", "AX")
                    .header("channelId", "AXS")
                    .body(json)
                    .post(ResMapList.get(endPointURL))
                    .then()
                    .statusCode(200)
                    .extract()
                    .response().getBody().asString();

            JSONObject obj = new JSONObject(res);
//            JSONArray val = (JSONArray) obj.get("orderDocumentsReferenceId");
//            responsedocreferenceid = (String) obj.get("orderDocumentsReferenceId");
//

        } catch (JSONException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }


    public String getDocProduceWIFI(String file_path, String endPointURL) {
        // String inputString;
        String responsedocreferenceid = null;
        try {
            //String file = ResMapList.get("pathtodocproducewifitext");
            String json = readFileAsString(file_path);

            RestAssured.baseURI = ResMapList.get(endPointURL);
            RestAssured.useRelaxedHTTPSValidation();
            String res = given().log().all().header("Accept", "application/json")
                    .header("Content-Type", "application/json")
                    .header("TransactionId", "123457570-374747-3333")
                    .header("appId", "AX")
                    .header("channelId", "AXS")
                    .body(json)
                    .post(ResMapList.get(endPointURL))
                    .then()
                    .statusCode(200)
                    .extract()
                    .response().getBody().asString();

            JSONObject obj = new JSONObject(res);
//            JSONArray val = (JSONArray) obj.get("orderDocumentsReferenceId");
            responsedocreferenceid = (String) obj.get("orderDocumentsReferenceId");

        } catch (JSONException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return responsedocreferenceid;
    }

    public String createTxtFileFromJson(String filename, String jsonPath) {
        String filePath = null;
        try {
            String file = ResMapList.get(jsonPath);
            String json = readFileAsString(file);
            //System.out.println(json);
            filePath = ".\\src\\main\\resources\\reports\\" + filename + ".txt";
            FileWriter myWriter = new FileWriter(filePath);
            myWriter.write(json);
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return filePath;
    }
}
