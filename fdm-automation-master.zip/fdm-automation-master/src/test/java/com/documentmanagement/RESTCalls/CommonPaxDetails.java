package com.documentmanagement.RESTCalls;

import com.documentmanagement.GenericMethods.GenericMethods;
import com.documentmanagement.PageObjecs.AdminTool;
import com.documentmanagement.handlers.ReadProperties;
import io.restassured.RestAssured;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

import javax.net.ssl.SSLHandshakeException;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Scanner;

import static io.restassured.RestAssured.given;


public class CommonPaxDetails {

    DocProduceWIFI docPrd = new DocProduceWIFI();
    GenericMethods gm = new GenericMethods();


    HashMap<String, String> ResMapList = ReadProperties
            .getAllValue(".\\src\\main\\resources\\Configuration.properties");
    private String jsonBody;

    public String Seg1ArrAirportcode(String filePath) throws Exception {
        String retailItemsJsonIndex = null;
        try {
            String file = ResMapList.get(filePath);
            String json = docPrd.readFileAsString(file);
            JSONObject obj = new JSONObject(json);
            JSONObject val1 = new JSONObject(obj.get("order").toString());
            JSONObject orderDataList = new JSONObject(val1.get("orderDataList").toString());
            JSONArray orderItemsJSON = new JSONArray(orderDataList.get("passengerItinerarySegment").toString());
            JSONObject orderItemsJSONIndex = new JSONObject(orderItemsJSON.get(0).toString());
            JSONObject retailItemsJson = new JSONObject(orderItemsJSONIndex.get("originAirport").toString());
            retailItemsJsonIndex = retailItemsJson.get("airportCode").toString();
            retailItemsJson.append("airportCode", "Shamili");
            // reasonForIssuanceSubCodeVal = (productInformationJson.get("reasonForIssuanceSubCode").toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return retailItemsJsonIndex;
    }

    public WebDriver setJSONDocprdsdt(String firstname, String lastname)
    {
        WebDriver driver = null;
        try {
           driver = gm.launchEMD_plus();
//            Webdriver driver = null;
            AdminTool ad = new AdminTool();
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MMM-yy");
            LocalDateTime now = LocalDateTime.now();
            String today_date = dtf.format(now);
            ad.click_lastnamecheck();
            ad.enter_lastname(lastname);
            ad.enter_issuedaterange(today_date);
            ad.enter_issuedaterange1(today_date);
            ad.click_find();

            ad.find_pax_names(firstname, lastname);
            Thread.sleep(3000);

            String passname = ad.getPassengerName();
            String docnum = ad.getDocumentNumber();
            gm.writeExcel(passname, docnum);

            Thread.sleep(3000);
            ad.click_coupon_details();
        } catch (JSONException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return driver;
    }

    public void postJSON(String endPointURL, String json) throws SSLHandshakeException {
        try {
            RestAssured.baseURI = ResMapList.get(endPointURL);
            RestAssured.useRelaxedHTTPSValidation();
            given().log().all().header("Accept", "application/json")
                    .header("Content-Type", "application/json")
                    .header("TransactionId", gm.getUUID())
                    .header("appId", "AX")
                    .header("channelId", "AXS")
                    .body(json)
                    .post(ResMapList.get(endPointURL))
                    .then()
                    .statusCode(200)
                    .extract()
                    .response().getBody().asString();
            //System.out.println("Contents of the file: " + fileContents);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String jsonBody(String LastName, String FirstName, String AccDocNum, String Seg1ofoneArrAirportcode, String Seg1oftwoArrAirportcode, String Seg1ofoneDestAirportcode, String Seg1oftwoDestAirportcode, String Seg1ofonescheduledDepartureLocalTs, String Seg1oftwoscheduledDepartureLocalTs, String Seg1ofonescheduledArrivalLocalTs, String Seg1oftwoscheduledArrivalLocalTs, String Seg1ofonemarketingFlightNum, String Seg1oftwomarketingFlightNum, String Seg1ofoneoperatingFlightNum, String Seg1oftwooperatingFlightNum) {
        String val = "{\n" +
                "  \"order\": {\n" +
                "    \"orderId\": \"b53bec61-2b85-40ab-be18-d0b6b115ee9c\",\n" +
                "    \"pointOfSale\": {\n" +
                "      \"countryCode\": \"US\",\n" +
                "      \"officeTypeCode\": null,\n" +
                "      \"pointOfSaleCityCode\": \"ATL\",\n" +
                "      \"pointOfSaleId\": \"ATLFTO\",\n" +
                "      \"soldByTravelAgency\": true,\n" +
                "      \"deviceTypeText\": null,\n" +
                "      \"ipAddressText\": null,\n" +
                "      \"browserTypeText\": null,\n" +
                "      \"vdnCode\": null,\n" +
                "      \"customerId\": \"D028244\",\n" +
                "      \"digitalSaleMetadataText\": null\n" +
                "    },\n" +
                "    \"formsOfPayment\": [\n" +
                "        {\n" +
                "        \"paymentReferenceId\": \"7EC7A75982BE413DA50A57000F811E0D\",\n" +
                "          \"paymentMethod\": {\n" +
                "          \"paymentMethodTypeName\": \"CREDIT CARD\",\n" +
                "          \"paymentCard\": {\n" +
                "            \"expirationMonthNum\": \"12\",\n" +
                "            \"expirationYearNum\": \"20\",\n" +
                "            \"paymentCardNetworkCode\": \"VI\",\n" +
                "            \"paymentCardNum\": \"37244Z6FIHG2118\",\n" +
                "            \"cardVerificationValueNum\": \"1234\"\n" +
                "          }\n" +
                "        }\n" +
                "      }\n" +
                "    ],\n" +
                "    \"orderItems\": [\n" +
                "      {\n" +
                "        \"orderItemNum\": \"4b76070a-b6a0-4131-8acc-047cf3ec637a\",\n" +
                "        \"productCategoryId\": \"ChangeFlight\",\n" +
                "        \"orderItemCreationUtcTs\": null,\n" +
                "        \"orderItemStatusCode\": \"CO\",\n" +
                "        \"orderItemPricing\": {\n" +
                "          \"totalAmt\": {\n" +
                "            \"currencyEquivalentPrice\": {\n" +
                "              \"decimalPrecisionCnt\": 2,\n" +
                "              \"currencyAmt\": 7500,\n" +
                "              \"currencyCode\": \"USD\"\n" +
                "            }\n" +
                "          },\n" +
                "          \"baseAmt\": {\n" +
                "            \"currencyEquivalentPrice\": {\n" +
                "              \"decimalPrecisionCnt\": 2,\n" +
                "              \"currencyAmt\": 7500,\n" +
                "              \"currencyCode\": \"USD\"\n" +
                "            }\n" +
                "          }\n" +
                "        },\n" +
                "        \"overridePrice\": {},\n" +
                "        \"retailItems\": [\n" +
                "                  {\n" +
                "            \"retailItemId\": \"1\",\n" +
                "            \"accountableDocuments\": [\n" +
                "              {\n" +
                "                \"accountableDocumentNum\": \"" + AccDocNum + "\",\n" +
                "                \"documentCategoryCode\": \"TKT\"\n" +
                "              }\n" +
                "            ],\n" +
                "            \"tripIds\": [\n" +
                "              \"01\"\n" +
                "            ],\n" +
                "            \"flightSegmentIds\": [\n" +
                "              \"01-02\"\n" +
                "            ],\n" +
                "            \"passengerRefIds\": [\n" +
                "              \"01.01\"\n" +
                "            ],\n" +
                "            \"paymentStatusCode\": \"PD\",\n" +
                "            \"retailItemMetaData\": {\n" +
                "              \"productInformation\": {\n" +
                "                \"productId\": \"DLC01\",\n" +
                "                \"productName\": \"Same Day Confirmed\",\n" +
                "                \"productShortDesc\": \"Same Day Confirmed\",\n" +
                "                \"productLongDesc\": \"Same Day Confirmed\",\n" +
                "                \"productCategoryCode\": \"EEC\",\n" +
                "                \"productCategoryName\": \"EEC\",\n" +
                "                \"productSubCategoryCode\": \"EEC\",\n" +
                "                \"productSubCategoryName\": \"EEC\",\n" +
                "                \"marketedProductTypeCode\": \"EEC\",\n" +
                "                \"productTypeCode\": \"C01\",\n" +
                "                \"externalProductId\": \"C01\",\n" +
                "                \"reasonForIssuanceCode\": \"I\",\n" +
                "                \"reasonForIssuanceSubCode\": \"EEC\",\n" +
                "                \"purchaseRuleFormOfPayment\": [\n" +
                "                  \"credit_card\"\n" +
                "                ],\n" +
                "                \"typeCode\": \"C\"\n" +
                "              }\n" +
                "            }\n" +
                "          },\n" +
                "            {\n" +
                "            \"retailItemId\": \"2\",\n" +
                "            \"accountableDocuments\": [\n" +
                "              {\n" +
                "                \"accountableDocumentNum\": \"" + AccDocNum + "\",\n" +
                "                \"documentCategoryCode\": \"TKT\"\n" +
                "              }\n" +
                "            ],\n" +
                "            \"tripIds\": [\n" +
                "              \"01\"\n" +
                "            ],\n" +
                "            \"flightSegmentIds\": [\n" +
                "              \"01-02\"\n" +
                "            ],\n" +
                "            \"passengerRefIds\": [\n" +
                "              \"01.01\"\n" +
                "            ],\n" +
                "            \"paymentStatusCode\": \"PD\",\n" +
                "            \"retailItemMetaData\": {\n" +
                "              \"productInformation\": {\n" +
                "                \"productId\": \"MB3MZ\",\n" +
                "                \"productName\": \"MILEAGE BOOSTER - 3000 MILES\",\n" +
                "                \"productShortDesc\": \"Mileage Booster - 3000 Miles\",\n" +
                "                \"productLongDesc\": \"Mileage Booster - 3000 Mile\",\n" +
                "                \"productCategoryCode\": \"G\",\n" +
                "                \"productCategoryName\": \"ZM3\",\n" +
                "                \"productSubCategoryCode\": \"ZM3\",\n" +
                "                \"productSubCategoryName\": \"ZM3\",\n" +
                "                \"marketedProductTypeCode\": \"ZM3\",\n" +
                "                \"productTypeCode\": \"\",\n" +
                "                \"externalProductId\": \"\",\n" +
                "                \"reasonForIssuanceCode\": \"G\",\n" +
                "                \"reasonForIssuanceSubCode\": \"ZM3\",\n" +
                "                \"purchaseRuleFormOfPayment\": [\n" +
                "                  \"credit_card\"\n" +
                "                ],\n" +
                "                \"typeCode\": \"C\"\n" +
                "              }\n" +
                "            }\n" +
                "          }\n" +
                "        ]\n" +
                "      }\n" +
                "    ],\n" +
                "    \"orderDataList\": {\n" +
                "      \"customers\": [\n" +
                "        {\n" +
                "          \"adultWithInfantPassengerId\": \"01.01\",\n" +
                "          \"customerId\": \"9969713554997\",\n" +
                "          \"firstNameNum\": \"01\",\n" +
                "          \"lastNameNum\": \"01\",\n" +
                "          \"passengerId\": \"01.01\",\n" +
                "          \"personName\": {\n" +
                "            \"firstName\": \"" + FirstName + "\",\n" +
                "            \"lastName\": \"" + LastName + "\"\n" +
                "          }\n" +
                "        }\n" +
                "      ],\n" +
                "      \"passengerItinerarySegment\": [\n" +
                "        {\n" +
                "          \"actionCode\": \"HK\",\n" +
                "          \"compartmentName\": \"C\",\n" +
                "          \"destinationAirport\": {\n" +
                "            \"airportCode\": \"" + Seg1ofoneDestAirportcode + "\"\n" +
                "          },\n" +
                "          \"destinationAirportCode\": \"" + Seg1ofoneDestAirportcode + "\",\n" +
                "          \"flightSegmentNum\": \"01\",\n" +
                "          \"marketingCarrier\": {\n" +
                "            \"carrierCode\": \"DL\"\n" +
                "          },\n" +
                "          \"marketingFlightNum\": \"" + Seg1ofonemarketingFlightNum + "\",\n" +
                "          \"operatingCarrier\": {\n" +
                "            \"carrierCode\": \"DL\"\n" +
                "          },\n" +
                "          \"operatingCarrierCode\": \"DL\",\n" +
                "          \"operatingFlightNum\": \"" + Seg1ofoneoperatingFlightNum + "\",\n" +
                "          \"originAirport\": {\n" +
                "            \"airportCode\": \"" + Seg1ofoneArrAirportcode + "\"\n" +
                "          },\n" +
                "          \"originAirportCode\": \"" + Seg1ofoneArrAirportcode + "\",\n" +
                "          \"scheduledArrivalLocalTs\": \"" + Seg1ofonescheduledArrivalLocalTs + "\",\n" +
                "          \"scheduledDepartureLocalTs\": \"" + Seg1ofonescheduledDepartureLocalTs + "\",\n" +
                "          \"scheduledDepartureUtcTs\": null,\n" +
                "          \"flightSegmentId\": \"01-01\",\n" +
                "          \"operatingClassOfServiceCode\": \"C\",\n" +
                "          \"marketingClassOfServiceCode\": \"C\"\n" +
                "        },\n" +
                "         {\n" +
                "          \"actionCode\": \"HK\",\n" +
                "          \"compartmentName\": \"C\",\n" +
                "          \"destinationAirport\": {\n" +
                "            \"airportCode\": \"" + Seg1oftwoDestAirportcode + "\"\n" +
                "          },\n" +
                "          \"destinationAirportCode\": \"" + Seg1oftwoDestAirportcode + "\",\n" +
                "          \"flightSegmentNum\": \"02\",\n" +
                "          \"marketingCarrier\": {\n" +
                "            \"carrierCode\": \"DL\"\n" +
                "          },\n" +
                "          \"marketingFlightNum\": \"" + Seg1oftwomarketingFlightNum + "\",\n" +
                "          \"operatingCarrier\": {\n" +
                "            \"carrierCode\": \"DL\"\n" +
                "          },\n" +
                "          \"operatingCarrierCode\": \"DL\",\n" +
                "          \"operatingFlightNum\": \"" + Seg1oftwooperatingFlightNum + "\",\n" +
                "          \"originAirport\": {\n" +
                "            \"airportCode\": \"" + Seg1oftwoArrAirportcode + "\"\n" +
                "          },\n" +
                "          \"originAirportCode\": \"" + Seg1oftwoArrAirportcode + "\",\n" +
                "          \"scheduledArrivalLocalTs\": \"" + Seg1oftwoscheduledArrivalLocalTs + "\",\n" +
                "          \"scheduledDepartureLocalTs\": \"" + Seg1oftwoscheduledDepartureLocalTs + "\",\n" +
                "          \"scheduledDepartureUtcTs\": null,\n" +
                "          \"flightSegmentId\": \"01-02\",\n" +
                "          \"operatingClassOfServiceCode\": \"C\",\n" +
                "          \"marketingClassOfServiceCode\": \"C\"\n" +
                "        }\n" +
                "      ],\n" +
                "      \"trips\": [\n" +
                "        {\n" +
                "          \"stopCnt\": \"1\",\n" +
                "          \"destinationAirportCode\": \"MSP\",\n" +
                "          \"originAirportCode\": \"ATL\",\n" +
                "          \"tripId\": \"0\",\n" +
                "          \"flightSegmentIdList\": [\n" +
                "            \"01-01\",\n" +
                "            \"01-02\"\n" +
                "          ]\n" +
                "        }\n" +
                "      ],\n" +
                "      \"retailItemDefinitions\": [\n" +
                "        {\n" +
                "          \"retailItemDefinitionId\": \"DLC01\",\n" +
                "          \"retailItemName\": \"Same Day Confirmed\",\n" +
                "          \"retailItemDesc\": \"Same Day Confirmed\"\n" +
                "        }\n" +
                "      ]\n" +
                "    }\n" +
                "  },\n" +
                "  \"messageSender\": {\n" +
                "    \"senderType\": null,\n" +
                "    \"userInfo\": {\n" +
                "      \"carrierCode\": \"DL\",\n" +
                "      \"applicationChannelName\": \"AXS\",\n" +
                "      \"cityCode\": \"DL\",\n" +
                "      \"userId\": null,\n" +
                "      \"passwordText\": null,\n" +
                "      \"agentDutyCode\": null,\n" +
                "      \"poolName\": null,\n" +
                "      \"testLabName\": \"tsbb\",\n" +
                "      \"roleId\": null\n" +
                "    }\n" +
                "  },\n" +
                "  \"orderItemsValidateReferenceId\": \"d7be9bd1-e823-40b1-a6d1-d7ca84bc2cee\"\n" +
                "}";

        return val;
    }
}