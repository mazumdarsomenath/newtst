package com.documentmanagement.Pojo.WIFI;
public class Minimum{
    public CurrencyEquivalentPrice currencyEquivalentPrice;
    public MilesEquivalentPrice milesEquivalentPrice;
}
