package com.documentmanagement.Pojo.WIFI;
public class PaymentCard{
    public String expirationMonthNum;
    public String expirationYearNum;
    public String paymentCardNetworkCode;
    public String paymentCardNum;
    public String cardVerificationValueNum;
}
