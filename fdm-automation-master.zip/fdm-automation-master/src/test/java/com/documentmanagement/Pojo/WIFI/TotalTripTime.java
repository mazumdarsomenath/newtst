package com.documentmanagement.Pojo.WIFI;
public class TotalTripTime{
    public int dayCnt;
    public int hourCnt;
    public int minuteCnt;
}
