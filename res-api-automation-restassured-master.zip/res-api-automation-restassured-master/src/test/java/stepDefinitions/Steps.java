package stepDefinitions;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.parser.ParseException;

import org.json.simple.parser.ParseException;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import resources.APIResources;
import resources.DEDOUtils;
import resources.Utils;

public class Steps extends Utils {
	RequestSpecification res;
	ResponseSpecification resbul;
	Response response;
	// public static String place_id;
	DEDOUtils dedoObj = new DEDOUtils();

	@Given("Request Payload is set for {string}")
	public void add_place_payload_with(String testDataFile) throws IOException {

		res = given().headers(headerConfig()).relaxedHTTPSValidation().spec(requestspecification())
				.body(new File("src\\test\\java\\testData\\" + testDataFile + ".json"));
	}

	@When("Agent calls {string} with {string} request")
	public void user_calls_with_http_request(String resources, String method) {
		APIResources apiresourse = APIResources.valueOf(resources);
		System.out.println(apiresourse.getResource());
		resbul = new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();
		if (method.equalsIgnoreCase("POST")) {
			response = res.when().post(apiresourse.getResource());

		} else if (method.equalsIgnoreCase("GET")) {
			response = res.when().get(apiresourse.getResource());
		}

	}

	@Then("the API call got success with status code {int}")
	public void the_API_call_got_success_with_status_code(Integer int1) {
		assertEquals(response.getStatusCode(), 200);

	}

	@Then("{string} in response body is {string}")
	public void in_response_body_is(String status, String Expstatusval) {

		assertEquals(getJsonpath(response, status), Expstatusval);

	}

	@Then("Print the response in the console")
	public void print_response() {
		String responseBody = response.getBody().asString();
		System.out.println(responseBody);
	}

	@Then("Verify the {string}")
	public void verify_the_loyaltyMemberId(String loyaltyMemberId) {
		// response.prettyPrint();
		System.out.println(
				"loyaltyMemberId is      " + response.getBody().path("omniProObject.loyaltyMember.loyaltyMemberId"));

		assertEquals(response.getBody().path("omniProObject.loyaltyMember.loyaltyMemberId"), loyaltyMemberId);
	}

	@Then("Verify the cevcNum {string}")
	public void verify_the_cevcNum(String cevcNum) {
		// response.prettyPrint();
		System.out.println("cevcNum is      " + response.getBody().path("omniProObject[0].cevcNum"));

		assertEquals(response.getBody().path("omniProObject[0].cevcNum"), cevcNum);
	}

	@Then("Verify the  message {string}")
	public void verify_the_message(String message) {
		System.out.println("message is      " + response.getBody().path("omniProObject[0].cevcNum"));

		assertEquals(response.getBody().path("errorList[0].message"), message);
	}

	@Then("Verify the  firstName {string}")
	public void verify_the_firstName(String firstName) {
		System.out.println("message is      " + response.getBody().path("omniProObject[0].cevcNum"));
		assertEquals(response.getBody().path("errorList[0].message"), firstName);
	}

	@Then("Verify the origin and destination in the response are {string} and {string}")
	public void verify_origin_dest_in_faresCal(String Origin, String Destn) {
		// response.prettyPrint();
//		String name = response.getBody().path("omniProObject.fareQuotes[0].fareInfo.fareOriginAirportCode");
		assertEquals(response.getBody().path("omniProObject.fareQuotes[0].fareInfo.fareOriginAirportCode"), Origin);
		assertEquals(response.getBody().path("omniProObject.fareQuotes[0].fareInfo.fareDestinationCityCode"), Destn);

	}

	@When("Generate a Revenue PNR using DEDO")
	public void generate_PNR_DEDO() throws IOException {
		dedoObj.generateTestData();
	}

	@Then("Search a Customer using PNR and LastName")
	public void search_customer() throws IOException {
		dedoObj.omp_search_lastname_pnr();
	}

	@Then("Update the Generated DATA in the RequestBody")
	public void update_genData() throws IOException, ParseException {
		dedoObj.updateTestData();
	}

//	@Then("Verify the SkyMile Number of the user is {string}")
//	public void verify_smNum(String skymileNum) throws IOException {
//		dedoObj.verify_skymile_num(String SM);
//	}

}
