package com.documentmanagement.PageObjecs;

import com.documentmanagement.GenericMethods.GenericMethods;//*[@id="form1"]/table/tbody/tr[3]/td/div/table/tbody/tr[8]/td[19]/input
import com.mongodb.client.model.geojson.codecs.LineStringCodec;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class AdminTool {
	private  WebDriver driver;
	 By lastname_check = By.id("surnameId4");
	 By last_name = By.id("surnameTxt");
	 By issue_date_range = By.id("txt8");
	 By issue_date_range1 = By.id("txt9");
	 By find_button = By.id("findBttn2");
	 By passenger_name = By.id("form1_emdDetailDTO_nameOfPassenger");
	 By document_number = By.id("docNumberId");
	 By link_coupon_details = By.xpath("//*[text()='Coupon Details']");
	 By history = By.id("showHistory");
	 String data_table = "//table[@class='searchResultTable']//td[text()='%s']/preceding-sibling::td/a[@href]";
     By amount_currency = By.xpath("//*[@id=\"form1\"]/table/tbody/tr[3]/td/div/table/tbody/tr[8]/td[19]/input");
     By amount_currency1 = By.xpath("//*[@id=\"form1\"]/table/tbody/tr[3]/td/div/table/tbody/tr[9]/td[19]/input");
	 By amount_currency2 = By.xpath("//*[@id=\"form1\"]/table/tbody/tr[3]/td/div/table/tbody/tr[10]/td[19]/input");
	 By amount_currency3 = By.xpath("//*[@id=\"form1\"]/table/tbody/tr[3]/td/div/table/tbody/tr[11]/td[19]/input");
	 By amount_currency4 = By.xpath("//*[@id=\"form1\"]/table/tbody/tr[3]/td/div/table/tbody/tr[12]/td[19]/input");
     By ticket_number = By.xpath("//*[@id=\"form1\"]/table/tbody/tr[3]/td/div/table/tbody/tr[8]/td[23]/input");
     By amt_cur_clmn = By.xpath("//*[@id=\"form1\"]/table/tbody/tr");
     By total_tablerows = By.xpath("//tr[@class = 'flownNotPresent']");


	GenericMethods gm = new GenericMethods();


	public AdminTool() {
		driver = GenericMethods.driver;
	}

	public  void enter_lastname(String lastname) {
		driver.findElement(last_name).sendKeys(lastname);
	}
	public  void enter_issuedaterange(String issuedaterange) { driver.findElement(issue_date_range).sendKeys(issuedaterange); }
	public  void enter_issuedaterange1(String issuedaterange1) { driver.findElement(issue_date_range1).sendKeys(issuedaterange1); }

	public  void click_find() throws InterruptedException {
		driver.findElement(find_button).click();
		Thread.sleep(3000);
	}

	public String amount_val1(WebDriver driver) {

		String actual_amount = null;
				WebElement text = driver.findElement(amount_currency1);
				actual_amount = text.getAttribute("value");
				System.out.println("Heading of child window is " + text.getAttribute("value"));
		return actual_amount;
	}

	public String amount_val2(WebDriver driver) {
//		String mainwindow = driver.getWindowHandle();
//		Set<String> s1 = driver.getWindowHandles();
//		Iterator<String> i1 = s1.iterator();
		String actual_amount = null;
//		while (i1.hasNext()) {
//			String ChildWindow = i1.next();
//			if (!mainwindow.equalsIgnoreCase(ChildWindow)) {
//				driver.switchTo().window(ChildWindow);
				WebElement text = driver.findElement(amount_currency2);
				actual_amount = text.getAttribute("value");
				System.out.println("Heading of child window is " + text.getAttribute("value"));

//			}

//		}
		return actual_amount;
	}

	public String amount_val3(WebDriver driver ) {
//		String mainwindow = driver.getWindowHandle();
//		Set<String> s1 = driver.getWindowHandles();
//		Iterator<String> i1 = s1.iterator();
		String actual_amount = null;
//		while (i1.hasNext()) {
//			String ChildWindow = i1.next();
//			if (!mainwindow.equalsIgnoreCase(ChildWindow)) {
//				driver.switchTo().window(ChildWindow);
				WebElement text = driver.findElement(amount_currency3);
				actual_amount = text.getAttribute("value");
				System.out.println("Heading of child window is " + text.getAttribute("value"));

//			}
//
//		}
		return actual_amount;
	}

	public String amount_val4(WebDriver driver) {
//		String mainwindow = driver.getWindowHandle();
//		Set<String> s1 = driver.getWindowHandles();
//		Iterator<String> i1 = s1.iterator();
		String actual_amount = null;
//		while (i1.hasNext()) {
//			String ChildWindow = i1.next();
//			if (!mainwindow.equalsIgnoreCase(ChildWindow)) {
//				driver.switchTo().window(ChildWindow);
				WebElement text = driver.findElement(amount_currency4);
				actual_amount = text.getAttribute("value");
				System.out.println("Heading of child window is " + text.getAttribute("value"));
//
//			}
//
//		}
		return actual_amount;
	}

	public String getPassengerName(){
		WebElement val = driver.findElement(passenger_name);
		return val.getAttribute("value");
	}

	public String getDocumentNumber(){
		WebElement val = driver.findElement(document_number);
		return val.getAttribute("value");
	}

	public  void click_lastnamecheck() throws InterruptedException {
		driver.findElement(lastname_check).click();
		Thread.sleep(3000);
	}

	public  void click_coupon_details() throws InterruptedException {
		driver.findElement(link_coupon_details).click();
		Thread.sleep(3000);
	}

	public  void history_click() throws InterruptedException {
		driver.findElement(history).click();
		Thread.sleep(3000);
	}

	public Set getWindowID()
	{
		Set<String> lst = driver.getWindowHandles();
		lst.remove(driver.getWindowHandle());
		return lst;
	}

	public void switchToDesiredWindow(Set set)
	{
		driver.switchTo().window(set.stream().findFirst().toString());
	}

	public void find_pax_names(String firstname, String lastname )
	{
		String document_number_xpath = String.format(data_table, firstname);
		List<WebElement> table_list = driver.findElements(By.xpath(document_number_xpath));
		String document_number  = table_list.get(table_list.size()-1).getText();
		table_list.get(table_list.size()-1).click();
	}

		public String get_currency_last_row(WebDriver driver) throws InterruptedException {
		//driver.findElements((amount_currency));
			String mainwindow = driver.getWindowHandle();
		Set<String> s1 = driver.getWindowHandles();
		Iterator<String> i1 = s1.iterator();
		String actual_amount = null;

		while (i1.hasNext()) {
			String ChildWindow = i1.next();
			if (!mainwindow.equalsIgnoreCase(ChildWindow)) {
				driver.switchTo().window(ChildWindow);
				int val = (8 + driver.findElements(total_tablerows).size())-1;
				WebElement text = driver.findElement(By.xpath("//*[@id=\"form1\"]/table/tbody/tr[3]/td/div/table/tbody/tr["+val+"]/td[19]/input"));
				actual_amount = text.getAttribute("value");
				System.out.println("Heading of child window is " + text.getAttribute("value"));
			}
		}

		return actual_amount;
	}

	public void getbalance_row(WebDriver driver, String exp_val) throws InterruptedException {
		//driver.findElements((amount_currency));
				for (int i = 0; i >= driver.findElements(total_tablerows).size() - 2; i++) {
					int val = (8 + i);
					WebElement text = driver.findElement(By.xpath("//*[@id=\"form1\"]/table/tbody/tr[3]/td/div/table/tbody/tr[" + val + "]/td[19]/input"));
					String actual_amount = text.getAttribute("value");
					Assert.assertEquals("!!!Not Equals", actual_amount, exp_val);
				}
			}

	public String ticket_number(WebDriver driver) {
     	String actual_tkt_num = null;
		WebElement text = driver.findElement(ticket_number);
		actual_tkt_num = text.getAttribute("value");
		System.out.println("Heading of child window is " + text.getAttribute("value"));
		return actual_tkt_num;
	}

	public int find_amountcurrency_val(WebDriver driver, String val, String balance_expected_val) {
		Set<String> s1 = driver.getWindowHandles();
		Iterator<String> i1 = s1.iterator();
		List<String> amount_val = new ArrayList<>();
		String balance_amount_val = null;
		while (i1.hasNext()) {
			String ChildWindow = i1.next();
			driver.switchTo().window(ChildWindow);
			List<WebElement> table_list = driver.findElements(amt_cur_clmn);
			for (int i = 1; i < table_list.size()-1; i++) {
				if (driver.findElement(By.xpath("//*[@id=\"form1\"]/table/tbody/tr[3]/td/div/table/tbody/tr["+ (8+i) +"]/td[19]/input")).getAttribute("value").contentEquals(val)) {
					amount_val.add(driver.findElement(By.xpath("//*[@id=\"form1\"]/table/tbody/tr[3]/td/div/table/tbody/tr["+ (8+i) +"]/td[19]/input")).getAttribute("value"));
				}else{
					balance_amount_val = (driver.findElement(By.xpath("//*[@id=\"form1\"]/table/tbody/tr[3]/td/div/table/tbody/tr["+ (8+i) +"]/td[19]/input")).getAttribute("value"));
					Assert.assertEquals("!!!error, Data mismatch",balance_amount_val, balance_expected_val);
				}
			}
		}
		return amount_val.size();
	}

//	public String getCurrency_o//	ther_rows(WebDriver driver, String expected_value) {
//		//driver.findElements((amount_currency));
//		String mainwindow = driver.getWindowHandle();
//		Set<String> s1 = driver.getWindowHandles();
//		Iterator<String> i1 = s1.iterator();
//		WebElement text = null;
//		while (i1.hasNext()) {
//			String ChildWindow = i1.next();
//			if (!mainwindow.equalsIgnoreCase(ChildWindow)) {
//				driver.switchTo().window(ChildWindow);
//				//if() {
//				text = driver.findElement(amount_currency);
//				System.out.println("Heading of child window are " + text.getAttribute("value"));
//				//}
//
////				driver.close();
////				System.out.println("Child window closed");
//			}
//		}
//
//
//	//  Switch back to the main window which is the parent window.
//
//
//
//	}
}
























//	{
//		String headers = "//tr[@bgcolor]//td[text()]";
//		List<WebElement> headersList = driver.findElements(By.xpath(headers));
//		Optional<WebElement> amount = headersList.stream().filter(x -> x.getText().equals("Amt/Currency")).findFirst();
//		int amountIndex;
//		if (amount.isPresent())
//			amountIndex = headersList.indexOf(amount);
//
//		String AllRows = "//tr[@class='flownNotPresent']";
//		String amountTextPath = "//tr[@class='flownNotPresent'][%s]//td[%s]";
//		List<WebElement> allRows = driver.findElements(By.xpath(AllRows));
//		for(int i = 0;i<allRows.size();i++) {
//			String amounts = driver.findElement(By.xpath(String.format(amountTextPath, i,20))).getText();
//			System.out.println(amounts);
//			String ticket = driver.findElement(By.xpath(String.format(amountTextPath, i,24))).getText();
//			System.out.println(ticket);
//		}
//	}


//}
//	//public LoginPage() {
//		driver = GenericMethods.driver;
//	}