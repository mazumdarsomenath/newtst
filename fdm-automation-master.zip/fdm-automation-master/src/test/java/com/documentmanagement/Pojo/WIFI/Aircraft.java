package com.documentmanagement.Pojo.WIFI;
public class Aircraft{
    public Object fleetTypeCode;
    public Object subFleetTypeCode;
    public boolean newSubFleetType;
}
