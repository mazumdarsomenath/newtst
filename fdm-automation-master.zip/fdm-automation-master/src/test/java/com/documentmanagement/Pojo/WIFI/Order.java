package com.documentmanagement.Pojo.WIFI;
import java.util.List; 
public class Order{
    public String orderId;
    public PointOfSale pointOfSale;
    public List<FormsOfPayment> formsOfPayment;
    public List<OrderItem> orderItems;
    public OrderDataList orderDataList;
}
