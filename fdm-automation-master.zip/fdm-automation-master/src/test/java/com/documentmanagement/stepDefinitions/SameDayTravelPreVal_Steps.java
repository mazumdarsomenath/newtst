package com.documentmanagement.stepDefinitions;

import com.cucumber.listener.Reporter;
import com.documentmanagement.GenericMethods.GenericMethods;
import com.documentmanagement.PageObjecs.AdminTool;
import com.documentmanagement.RESTCalls.CommonPaxDetails;
import com.documentmanagement.RESTCalls.DocProduceWIFI;
import com.documentmanagement.RESTCalls.SameDayTravelPreVal;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;


public class SameDayTravelPreVal_Steps {
    DocProduceWIFI docprd = new DocProduceWIFI();
    GenericMethods gm = new GenericMethods();
    SameDayTravelPreVal sameDay = new SameDayTravelPreVal();
    AdminTool ad = new AdminTool();
    CommonPaxDetails com = new CommonPaxDetails();


    String file_path = null;
    String response = null;
    String firstName = null;
    String lastName = null;
    String actual_Val = null;
    WebDriver driver = null;

    @Given("^a request for Same Day Travel with RFIC as \"([^\"]*)\"$")
    public void aRequestForSameDayTravel(String val) throws Exception {
        String reasonCodeVal = sameDay.reasonForIssuanceSubCode();
//        String paxnamesVal = sameDay.valpaxnames();
        firstName = gm.dynamicNames();
        lastName = gm.dynamicNames();
        file_path = docprd.createTxtFileFromJson("ReasonForIssuanceSubCode", "samedaytravelprevalJson");
        docprd.setJSONDocprdwifi("samedaytravelprevalJson", "nil", firstName, lastName, file_path);
        gm.readTextFile(reasonCodeVal, val, file_path);
    }

    @When("^I perform a post call with RFIC value$")
    public void iPerformAPostCallWithRFICAValue() throws Throwable {
        response = sameDay.getsamedaytravelresp(file_path);
    }

    @Then("^I verify message text in response as messageText: \"([^\"]*)\"$")
    public void iVerifyMessageTextInResponseAs(String expectedValue) throws Throwable {
        sameDay.getvalerrormes(response, expectedValue);
    }

    @Then("^I verify message text as \"([^\"]*)\": \"([^\"]*)\"$")
    public void iVerifyMessageTextAs(String expectedValue, String expectedStatus) throws Throwable {
        sameDay.getvalmes(response, expectedStatus, expectedValue);
    }

    @When("^I make a post call to given \"([^\"]*)\"$")
    public void iMakeAPostCallToGiven(String endPointurl) throws Throwable {
        response = docprd.getResponse(file_path, endPointurl);
    }

    @Given("^a request for \"([^\"]*)\" retail item for Same Day Travel$")
    public void aRequestForRetailItemForSameDayTravel(String jSonBody) throws Throwable {
        file_path = jSonBody;
    }

    @Then("^I verify message text in response as Text message: \"([^\"]*)\"$")
    public void iVerifyMessageTextInResponseAsTextMessage(String expectedValue) throws Throwable {
        sameDay.getvalerrormesg(response, expectedValue);
    }

//    @Then("^I verify WIFI document with LastName \"([^\"]*)\" $")
//    public void iVerifyWIFIDocumentWithLastName() throws Exception {
//        file_path = docprd.createTxtFileFromJson(firstName, "samedaytravelprevalJson");
//        sameDay.setJSONDocprdsdt("samedaytravelprevalJson", file_path);
//    }

    @Then("^I verify WIFI document with LastName \"([^\"]*)\"$")
    public void iVerifyWIFIDocumentWithLastName(String jSonBody) throws Throwable {
        file_path = docprd.createTxtFileFromJson(firstName, jSonBody);
        driver = sameDay.setJSONDocprdsdt(jSonBody);
        Reporter.addScreenCaptureFromPath(gm.getScreenShot(driver));
        gm.takeScreenShot(driver);
    }

    @And("^I Verify the EMD amount of first retails item is \"([^\"]*)\"$")
    public void iVerifyTheEMDAmountOfFirstRetailsItemIs(String Exp_value) throws Throwable {
        actual_Val = ad.get_currency_last_row(driver);
        Assert.assertEquals("!!!Error!!! Data is not matching", Exp_value, actual_Val);
       // gm.takeScreenShot();
    }

    @And("^I Verify the EMD amount of all the other retails items is \"([^\"]*)\"$")
    public void iVerifyTheEMDAmountOfAllTheOtherRetailsItemsIs(String Exp_value) throws Throwable {
        ad.getbalance_row(driver, Exp_value);
    }

    @And("^I save the ticket number$")
    public void iSaveTheTicketNumber() {
//        ad.ticket_number(driver);
        String tktnum = ad.ticket_number(driver);
//        String passname = ad.getPassengerName();
//        String docnum = ad.getDocumentNumber();
        sameDay.writeExcel(tktnum);
    }

    @Then("^I verify if \"([^\"]*)\": \"([^\"]*)\"$")
    public void iVerifyIf(String keyName, String expectedValue) throws Throwable {
        sameDay.getvalorderitems(response, keyName, expectedValue);
    }

    @And("^I verify the EMD amount of one retail item is \"([^\"]*)\" and all other retail items amount is \"([^\"]*)\"$")
    public void iVerifyTheEMDAmountOfOneRetailItemIsAndAllOtherRetailItemsAmountIs(String retailamt, String otherreatilamt) throws Throwable {
        int amount_val = ad.find_amountcurrency_val(driver, retailamt, otherreatilamt);
        Assert.assertEquals("!!!Error!!!, Amount value $75 display morethan 1 time in a table", amount_val, 1);
    }

    public String file_path() {
        return file_path;
    }

}