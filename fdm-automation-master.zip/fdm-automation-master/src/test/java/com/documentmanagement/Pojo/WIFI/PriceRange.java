package com.documentmanagement.Pojo.WIFI;
public class PriceRange{
    public Minimum minimum;
    public Maximum maximum;
}
