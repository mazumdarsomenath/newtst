package com.documentmanagement.Pojo.WIFI;
public class CancelEligibility{
    public Object eligibilityDesc;
    public boolean eligibility;
}
