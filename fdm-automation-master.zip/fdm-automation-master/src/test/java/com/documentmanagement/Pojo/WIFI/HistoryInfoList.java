package com.documentmanagement.Pojo.WIFI;
import java.util.List; 
public class HistoryInfoList{
    public Object ordinalNum;
    public Object pnrCreationText;
    public Object creditSignatureText;
    public Object actionReceivedFormText;
    public List<HistoryAction> historyActions;
}
