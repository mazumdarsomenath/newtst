package com.documentmanagement.Pojo.WIFI;
public class OnTimePerformance{
    public String unitOfMeasure;
    public int unitOfMeasureCnt;
}
