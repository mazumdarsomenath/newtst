package com.documentmanagement.Pojo.WIFI;
public class OrderItemEligibility{
    public Object eligibilityId;
    public CancelEligibility cancelEligibility;
    public ChangeEligibility changeEligibility;
    public RiskFreeCancellationEligibility riskFreeCancellationEligibility;
    public RefundEligibility refundEligibility;
    public SameDayChangeEligibility sameDayChangeEligibility;
    public ScheduleChangeEligibility scheduleChangeEligibility;
}
