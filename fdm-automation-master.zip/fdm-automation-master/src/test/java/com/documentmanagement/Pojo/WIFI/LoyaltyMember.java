package com.documentmanagement.Pojo.WIFI;
public class LoyaltyMember{
    public Object loyaltyMemberOwnerCode;
    public Object loyaltyMemberId;
    public String loyaltyProgramTierCode;
}
