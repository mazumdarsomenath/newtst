package com.documentmanagement.Pojo.WIFI;
public class ProductCategory{
    public Object productCategoryId;
    public Object marketedProductId;
    public Object descriptionText;
    public Price price;
}
