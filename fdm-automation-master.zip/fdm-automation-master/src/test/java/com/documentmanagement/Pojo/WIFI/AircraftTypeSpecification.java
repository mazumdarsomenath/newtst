package com.documentmanagement.Pojo.WIFI;
public class AircraftTypeSpecification{
    public String actualHostCarrierAircraftTypeCode;
    public String actualIndustryStandardAircraftTypeCode;
    public String plannedHostCarrierAircraftTypeCode;
    public String plannedIndustryStandardAircraftTypeCode;
    public String scheduledHostCarrierAircraftTypeCode;
}
