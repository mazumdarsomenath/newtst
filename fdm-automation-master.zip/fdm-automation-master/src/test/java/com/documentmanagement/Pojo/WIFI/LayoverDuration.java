package com.documentmanagement.Pojo.WIFI;
public class LayoverDuration{
    public int dayCnt;
    public int hourCnt;
    public int minuteCnt;
}
