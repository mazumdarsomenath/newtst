package com.documentmanagement.Pojo.WIFI;
public class TripEligibility{
    public Object eligibilityDesc;
    public boolean eligibility;
}
