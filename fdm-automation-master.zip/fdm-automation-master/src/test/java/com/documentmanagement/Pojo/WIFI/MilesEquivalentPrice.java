package com.documentmanagement.Pojo.WIFI;
public class MilesEquivalentPrice{
    public boolean cashPlusMiles;
    public int discountMileCnt;
    public int mileCnt;
}
