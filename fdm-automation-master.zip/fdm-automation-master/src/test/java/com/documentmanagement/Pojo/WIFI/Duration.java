package com.documentmanagement.Pojo.WIFI;
public class Duration{
    public int dayCnt;
    public int hourCnt;
    public int minuteCnt;
}
