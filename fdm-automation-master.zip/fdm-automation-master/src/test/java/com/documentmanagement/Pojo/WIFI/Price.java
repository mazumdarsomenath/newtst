package com.documentmanagement.Pojo.WIFI;
public class Price{
    public Object pricingOptionId;
    public TotalAmt totalAmt;
    public BaseAmt baseAmt;
    public TaxSummary taxSummary;
}
