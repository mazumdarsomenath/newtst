package com.documentmanagement.handlers;

import java.util.*;  
import java.io.*;  
public class ReadProperties { 

	public String getValue(String path , String key) {  
		Properties props = new Properties();
		FileInputStream file = null;
		HashMap<String, String> ResMapList = new HashMap<String, String>();
		try {
			file = new FileInputStream((new File(path)).getAbsolutePath()); //"./src/main/resources/TestData.properties"
			props.load(file);
			Set<String> keynames = props.stringPropertyNames();
			for (String keyname : keynames) {
				ResMapList.put(keyname, props.getProperty(keyname));
			}
			file.close();
			//sSystem.out.println(ResMapList.get(key));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ResMapList.get(key);
	}
	
	public static HashMap<String, String> getAllValue(String path) {  
		Properties props = new Properties();
		FileInputStream file = null;
		HashMap<String, String> ResMapList = new HashMap<String, String>();
		try {
			file = new FileInputStream((new File(path)).getAbsolutePath()); //"./src/main/resources/TestData.properties"
			props.load(file);
			Set<String> keynames = props.stringPropertyNames();
			for (String keyname : keynames) {
				ResMapList.put(keyname, props.getProperty(keyname));
			}
			file.close();
			//sSystem.out.println(ResMapList.get(key));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ResMapList;
	}

}  

