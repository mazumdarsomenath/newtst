package com.documentmanagement.Pojo.WIFI;
public class TravelDocument{
    public String birthDate;
    public DocumentPersonName documentPersonName;
    public String expirationDate;
    public String genderCode;
    public String importanceLevelCode;
    public String issueDate;
    public String issueisoCountryCode;
    public Object knownTravelerNum;
    public String nationalityisoCountryCode;
    public PersonName personName;
    public Object redressNum;
    public String residenceisoCountryCode;
    public String retrievedDocumentSourceTypeCode;
    public String swiped;
    public Object travelDocumentNum;
    public String travelDocumentTypeCode;
    public String verified;
}
