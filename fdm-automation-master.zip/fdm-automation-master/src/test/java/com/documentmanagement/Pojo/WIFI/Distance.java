package com.documentmanagement.Pojo.WIFI;
public class Distance{
    public String unitOfMeasure;
    public int unitOfMeasureCnt;
}
