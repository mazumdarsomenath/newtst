package com.documentmanagement.Pojo.WIFI;
public class Address{
    public Object addressAliasName;
    public Object addressLine1Text;
    public Object addressLine2Text;
    public Object businessName;
    public Object cityLocalityName;
    public Object contactPointCode;
    public Object countryCode;
    public Object countrySubdivisionCode;
    public Object districtTownName;
    public Object isoCountryCode;
    public Object mailingRecipientName;
    public Object postalCode;
    public Object prefectureLocationName;
}
