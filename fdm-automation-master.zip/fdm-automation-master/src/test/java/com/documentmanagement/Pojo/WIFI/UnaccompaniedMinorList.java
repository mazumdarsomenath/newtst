package com.documentmanagement.Pojo.WIFI;
import java.util.List; 
public class UnaccompaniedMinorList{
    public Object securityPinCode;
    public Object flightSegmentId;
    public UnaccompaniedMinorDropOff unaccompaniedMinorDropOff;
    public UnaccompaniedMinorPickUp unaccompaniedMinorPickUp;
    public List<UnaccompaniedMinor> unaccompaniedMinors;
}
