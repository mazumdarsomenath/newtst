package com.documentmanagement.Pojo.WIFI;

import java.util.Date;

public class Layover{
    public String arrivalFlightNum;
    public ArrivalMarketingCarrier arrivalMarketingCarrier;
    public ArrivalOperatingCarrier arrivalOperatingCarrier;
    public String changeOfAirport;
    public String departureFlightNum;
    public DepartureMarketingCarrier departureMarketingCarrier;
    public DepartureOperatingCarrier departureOperatingCarrier;
    public String destinationAirportCode;
    public String equipmentChange;
    public String layoverAirportCode;
    public LayoverDuration layoverDuration;
    public String originAirportCode;
    public Date scheduledArrivalLocalTs;
    public Date scheduledArrivalUtcTs;
    public Date scheduledDepartureLocalTs;
    public Date scheduledDepartureUtcTs;
}
