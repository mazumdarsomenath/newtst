package com.documentmanagement.RESTCalls;

import com.documentmanagement.GenericMethods.GenericMethods;
import com.documentmanagement.handlers.ReadProperties;
import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.http.ContentType;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import static io.restassured.RestAssured.given;

public class DocumentManagement {
    HashMap<String, String> ResMapList = ReadProperties
            .getAllValue(".\\src\\main\\resources\\Configuration.properties");
    GenericMethods gm = new GenericMethods();
    String filename = new SimpleDateFormat("yyyyMMddHHmmss'.csv'").format(new Date());
    public String csv_filepath = ("src/test/resources/reports/CSV_file_testResults" + filename);

    public String getAccessToken() {
        String token = null;
        try {
            String res_val = given().log().all().config(RestAssured.config()
                    .encoderConfig(EncoderConfig.encoderConfig()
                            .encodeContentTypeAs("x-www-form-urlencoded",
                                    ContentType.URLENC)))
                    .contentType("x-www-form-urlencoded")
                    .formParam("client_id", "yVHzH9H0JB340GwegUBA7tkaAKHdG4CM")
                    .formParam("client_secret", "kvz6vwAUahAQLntG")
                    .formParam("grant_type", "client_credentials")
                    .header("Content-Type", "application/x-www-form-urlencoded; charset=utf-8 ").
                            header("Accept", "application/json").request().post(ResMapList.get("tokenEndpoint"))
                    .then()
                    .statusCode(200)
                    .extract()
                    .response().getBody().asString();
            //System.out.print(res_val);
            JSONObject obj = new JSONObject(res_val);
            token = (String) obj.get("access_token");
       } catch (JSONException ex) {
            ex.printStackTrace();
        }
        return token;
    }

    public String getAccountDocNum(String docVal, String token) {
        String inputString;
        String accountDocNum = null;
        try {
            if (docVal.length() == 11) {
                inputString = "{\r\n"
                        + "  \"tpfSession\": {\r\n"
                        + "  \"cityCode\":\"ATL\",\r\n"
                        + "  \"tpfLoginId\":\"D006217\",\r\n"
                        + "  \"tpfPasswordText\":\"E0BACH\",\r\n"
                        + "  \"agentDutyCode\": null,\r\n"
                        + "  \"poolName\":\"DOTCOM/BOOKING\",\r\n"
                        + "  \"testLabName\":\"TSBB\",\r\n"
                        + "  \"applicationChannelName\":\"KO\"\r\n"
                        + "  },\r\n"
                        + "  \"searchByAccountableDocumentCriteria\": [\r\n"
                        + "        {\r\n"
                        + "            \"accountableDocumentNum\": \"00" + docVal + "\",\r\n"
                        + "            \"provideAssociatedDocument\" : \"true\"\r\n"
                        + "        }\r\n"
                        + "  ] \r\n"
                        + "}";
            } else if (docVal.length() == 12) {
                inputString = "{\r\n"
                        + "  \"tpfSession\": {\r\n"
                        + "  \"cityCode\":\"ATL\",\r\n"
                        + "  \"tpfLoginId\":\"D006217\",\r\n"
                        + "  \"tpfPasswordText\":\"E0BACH\",\r\n"
                        + "  \"agentDutyCode\": null,\r\n"
                        + "  \"poolName\":\"DOTCOM/BOOKING\",\r\n"
                        + "  \"testLabName\":\"TSBB\",\r\n"
                        + "  \"applicationChannelName\":\"KO\"\r\n"
                        + "  },\r\n"
                        + "  \"searchByAccountableDocumentCriteria\": [\r\n"
                        + "        {\r\n"
                        + "            \"accountableDocumentNum\": \"0" + docVal + "\",\r\n"
                        + "            \"provideAssociatedDocument\" : \"true\"\r\n"
                        + "        }\r\n"
                        + "  ] \r\n"
                        + "}";
            } else {
                inputString = "{\r\n"
                        + "  \"tpfSession\": {\r\n"
                        + "  \"cityCode\":\"ATL\",\r\n"
                        + "  \"tpfLoginId\":\"D006217\",\r\n"
                        + "  \"tpfPasswordText\":\"E0BACH\",\r\n"
                        + "  \"agentDutyCode\": null,\r\n"
                        + "  \"poolName\":\"DOTCOM/BOOKING\",\r\n"
                        + "  \"testLabName\":\"TSBB\",\r\n"
                        + "  \"applicationChannelName\":\"KO\"\r\n"
                        + "  },\r\n"
                        + "  \"searchByAccountableDocumentCriteria\": [\r\n"
                        + "        {\r\n"
                        + "            \"accountableDocumentNum\":\"" + docVal + "\",\r\n"
                        + "            \"provideAssociatedDocument\" : \"true\"\r\n"
                        + "        }\r\n"
                        + "  ] \r\n"
                        + "}";
            }
            String res = given().log().all().header("Authorization", "Bearer " + token + "").header("Content-Type", "application/json").header("Accept", "application/json").header("TransactionId", "1234567890").header("appId", "DC").header("channelId", "COM")
                    .body(inputString)
                    .post(ResMapList.get("docRetriveAPI"))
                    .then()
                    .statusCode(200)
                    .extract()
                    .response().getBody().asString();
           // System.out.print(res);
            // issue local date is 1 year back and expiration date should 1 year a head)
            JSONObject obj = new JSONObject(res);
            JSONArray val = (JSONArray) obj.get("accountableDocument");
            JSONObject jsonObj = new JSONObject(val.get(0).toString());
           accountDocNum = (jsonObj.getString("accountableDocumentNum"));

        } catch (JSONException ex) {
            ex.printStackTrace();
        }
        return accountDocNum;
    }

    public String getLocalDate(String docVal, String token){

        String inputString;
        String localDate = null;

        try {
            if (docVal.length() == 11) {
                inputString = "{\r\n"
                        + "  \"tpfSession\": {\r\n"
                        + "  \"cityCode\":\"ATL\",\r\n"
                        + "  \"tpfLoginId\":\"D006217\",\r\n"
                        + "  \"tpfPasswordText\":\"E0BACH\",\r\n"
                        + "  \"agentDutyCode\": null,\r\n"
                        + "  \"poolName\":\"DOTCOM/BOOKING\",\r\n"
                        + "  \"testLabName\":\"TSBB\",\r\n"
                        + "  \"applicationChannelName\":\"KO\"\r\n"
                        + "  },\r\n"
                        + "  \"searchByAccountableDocumentCriteria\": [\r\n"
                        + "        {\r\n"
                        + "            \"accountableDocumentNum\": \"00" + docVal + "\",\r\n"
                        + "            \"provideAssociatedDocument\" : \"true\"\r\n"
                        + "        }\r\n"
                        + "  ] \r\n"
                        + "}";
            }
                else if (docVal.length() == 12) {
                    inputString = "{\r\n"
                            + "  \"tpfSession\": {\r\n"
                            + "  \"cityCode\":\"ATL\",\r\n"
                            + "  \"tpfLoginId\":\"D006217\",\r\n"
                            + "  \"tpfPasswordText\":\"E0BACH\",\r\n"
                            + "  \"agentDutyCode\": null,\r\n"
                            + "  \"poolName\":\"DOTCOM/BOOKING\",\r\n"
                            + "  \"testLabName\":\"TSBB\",\r\n"
                            + "  \"applicationChannelName\":\"KO\"\r\n"
                            + "  },\r\n"
                            + "  \"searchByAccountableDocumentCriteria\": [\r\n"
                            + "        {\r\n"
                            + "            \"accountableDocumentNum\": \"0" + docVal + "\",\r\n"
                            + "            \"provideAssociatedDocument\" : \"true\"\r\n"
                            + "        }\r\n"
                            + "  ] \r\n"
                            + "}";
            } else {
                inputString = "{\r\n"
                        + "  \"tpfSession\": {\r\n"
                        + "  \"cityCode\":\"ATL\",\r\n"
                        + "  \"tpfLoginId\":\"D006217\",\r\n"
                        + "  \"tpfPasswordText\":\"E0BACH\",\r\n"
                        + "  \"agentDutyCode\": null,\r\n"
                        + "  \"poolName\":\"DOTCOM/BOOKING\",\r\n"
                        + "  \"testLabName\":\"TSBB\",\r\n"
                        + "  \"applicationChannelName\":\"KO\"\r\n"
                        + "  },\r\n"
                        + "  \"searchByAccountableDocumentCriteria\": [\r\n"
                        + "        {\r\n"
                        + "            \"accountableDocumentNum\":\"" + docVal + "\",\r\n"
                        + "            \"provideAssociatedDocument\" : \"true\"\r\n"
                        + "        }\r\n"
                        + "  ] \r\n"
                        + "}";
            }
                String res = given().log().all().header("Authorization", "Bearer " + token + "").header("Content-Type", "application/json").header("Accept", "application/json").header("TransactionId", "1234567890").header("appId", "DC").header("channelId", "COM")
                    .body(inputString)
                    .post(ResMapList.get("docRetriveAPI"))
                    .then()
                    .statusCode(200)
                    .extract()
                    .response().getBody().asString();
           // System.out.print(res);
            JSONObject obj = new JSONObject(res);
            JSONArray val = (JSONArray) obj.get("accountableDocument");
            JSONObject jsonObj = new JSONObject(val.get(0).toString());
            localDate = (jsonObj.getString("issueLocalDate"));
        } catch (JSONException ex) {
            ex.printStackTrace();
        }
        return localDate;
    }

    public String getExpDate(String docVal, String token) throws IOException {
        String inputString;
        String expDate = null;

        try {
            if (docVal.length() == 11) {
                inputString = "{\r\n"
                        + "  \"tpfSession\": {\r\n"
                        + "  \"cityCode\":\"ATL\",\r\n"
                        + "  \"tpfLoginId\":\"D006217\",\r\n"
                        + "  \"tpfPasswordText\":\"E0BACH\",\r\n"
                        + "  \"agentDutyCode\": null,\r\n"
                        + "  \"poolName\":\"DOTCOM/BOOKING\",\r\n"
                        + "  \"testLabName\":\"TSBB\",\r\n"
                        + "  \"applicationChannelName\":\"KO\"\r\n"
                        + "  },\r\n"
                        + "  \"searchByAccountableDocumentCriteria\": [\r\n"
                        + "        {\r\n"
                        + "            \"accountableDocumentNum\": \"00" + docVal + "\",\r\n"
                        + "            \"provideAssociatedDocument\" : \"true\"\r\n"
                        + "        }\r\n"
                        + "  ] \r\n"
                        + "}";
            } else if (docVal.length() == 12) {
                inputString = "{\r\n"
                        + "  \"tpfSession\": {\r\n"
                        + "  \"cityCode\":\"ATL\",\r\n"
                        + "  \"tpfLoginId\":\"D006217\",\r\n"
                        + "  \"tpfPasswordText\":\"E0BACH\",\r\n"
                        + "  \"agentDutyCode\": null,\r\n"
                        + "  \"poolName\":\"DOTCOM/BOOKING\",\r\n"
                        + "  \"testLabName\":\"TSBB\",\r\n"
                        + "  \"applicationChannelName\":\"KO\"\r\n"
                        + "  },\r\n"
                        + "  \"searchByAccountableDocumentCriteria\": [\r\n"
                        + "        {\r\n"
                        + "            \"accountableDocumentNum\": \"0" + docVal + "\",\r\n"
                        + "            \"provideAssociatedDocument\" : \"true\"\r\n"
                        + "        }\r\n"
                        + "  ] \r\n"
                        + "}";
            }else {
                inputString = "{\r\n"
                        + "  \"tpfSession\": {\r\n"
                        + "  \"cityCode\":\"ATL\",\r\n"
                        + "  \"tpfLoginId\":\"D006217\",\r\n"
                        + "  \"tpfPasswordText\":\"E0BACH\",\r\n"
                        + "  \"agentDutyCode\": null,\r\n"
                        + "  \"poolName\":\"DOTCOM/BOOKING\",\r\n"
                        + "  \"testLabName\":\"TSBB\",\r\n"
                        + "  \"applicationChannelName\":\"KO\"\r\n"
                        + "  },\r\n"
                        + "  \"searchByAccountableDocumentCriteria\": [\r\n"
                        + "        {\r\n"
                        + "            \"accountableDocumentNum\":\"" + docVal + "\",\r\n"
                        + "            \"provideAssociatedDocument\" : \"true\"\r\n"
                        + "        }\r\n"
                        + "  ] \r\n"
                        + "}";
            }

            String res = given().log().all().header("Authorization", "Bearer " + token + "").header("Content-Type", "application/json").header("Accept", "application/json").header("TransactionId", "1234567890").header("appId", "DC").header("channelId", "COM")
                    .body(inputString)
                    .post(ResMapList.get("docRetriveAPI"))
                    .then()
                    .statusCode(200)
                    .extract()
                    .response().getBody().asString();
         //   System.out.print(res);

            // issue local date is 1 year back and expiration date should 1 year a head)
            JSONObject obj = new JSONObject(res);
            JSONArray val = (JSONArray) obj.get("accountableDocument");
            JSONObject jsonObj = new JSONObject(val.get(0).toString());
            expDate = (jsonObj.getString("expirationDate"));
        } catch (JSONException ex) {
            ex.printStackTrace();
        }
        return expDate;
    }
}