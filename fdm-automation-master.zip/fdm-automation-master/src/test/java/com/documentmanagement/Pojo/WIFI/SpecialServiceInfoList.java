package com.documentmanagement.Pojo.WIFI;
import java.util.List; 
public class SpecialServiceInfoList{
    public Object requestTypeCode;
    public List<SpecialServiceRequest> specialServiceRequests;
}
