package com.documentmanagement.Pojo.WIFI;
public class SameDayChangeEligibility{
    public Object eligibilityDesc;
    public boolean eligibility;
}
