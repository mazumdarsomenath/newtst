package com.documentmanagement.Pojo.WIFI;
public class Maximum{
    public CurrencyEquivalentPrice currencyEquivalentPrice;
    public MilesEquivalentPrice milesEquivalentPrice;
}
