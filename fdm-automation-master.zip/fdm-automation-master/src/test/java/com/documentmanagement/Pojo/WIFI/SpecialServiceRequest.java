package com.documentmanagement.Pojo.WIFI;
import java.util.List; 
public class SpecialServiceRequest{
    public Object carrierCode;
    public Object passengerRefId;
    public List<Object> passengerSegmentRefId;
    public Object messageText;
    public Object specialServiceRequestNum;
    public Object statusCode;
}
