package resources;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Utils {

	static RequestSpecification reqsb;
	String Authorization = "eyJhbGciOiJSUzI1NiIsImtpZCI6ImsxIiwicGkuYXRtIjoiMyJ9.eyJzY29wZSI6WyJvcGVuaWQiLCJwcm9maWxlIiwib21uaXByb3JvbGVzIl0sImNsaWVudF9pZCI6Im9tbmlwcm9fb2lkYyIsImdyYW50X2lkIjoiNG81UzFCTFM5YmdUM3lpUEhvckxzQ3dobzZ3MVRwcTgiLCJpc3MiOiJodHRwczovL3NzYWFzaS5kZWx0YS5jb20iLCJqdGkiOiJZWkNWeThHZ0dQVURTbTJ3WE81akZkVGoxZWt0cE9wSyIsImRsbWlkIjoiMTgyODU1MCIsIm9yZ05hbWUiOiJEZWx0YSBBaXIgTGluZXMgKFNJKSIsInN1YmplY3QiOiIxODI4NTUwIiwiZXhwIjoxNjI4MTYxMTQ4fQ.MY8ysdCpgQ9yN6IVxv833G63jhwkYZvakmXa2u5hH1PKtVRbvT0iMMYRi0TGh_mmUhSgbXdpxDTzvIMnycrQBhzAJLKNZ-zDnZdhFJv8YET6xY3gDbij1faZWAJeh2jA0QGyMWEwWxK0RKvMLPMvU7SPTAxZbNDPRdzCewuFFKjBB-vtuJHAIJA5bsDWx0CnN6IaN5TrUByVjoJnVp5d6hwiD_xWKPNU8nB9PRCfe1FKuQjXR1bz-hE4LB0ma-Fp70jsIaeAUUZqgPWdWPKGaZlWbcYIM8x_wj2eazP7P1fzvBc8yE39rpeQE_Qe4HeX-a1HW1MxfofRMdOusQ99Yg";
	String X_UserContext = "eyJhbGciOiJSUzI1NiIsImtpZCI6IlZsdXM3aHEwS01NSmJDODVZNG1Sdy0wWG5BWSJ9.eyJzdWIiOiIxODI4NTUwIiwiYXVkIjoib21uaXByb19vaWRjIiwianRpIjoibnFob3ZQVENnT0dvdDdpRGdJaDZ2eCIsImlzcyI6Imh0dHBzOi8vc3NhYXNpLmRlbHRhLmNvbSIsImlhdCI6MTYyODE1MzkzNCwiZXhwIjoxNjI4MTU0MjM0LCJhdXRoX3RpbWUiOjE2MjgxNTM5MzQsImRsbWlkIjoiMTgyODU1MCIsInVwZGF0ZWRfYXQiOjE2MjgxNDI3MzUsInBwcl9udW1iZXIiOiIwMDE4Mjg1NTAiLCJuYW1lIjoiUGVrYW50aSwgRGluZXNoIiwic3RhdGlvbiI6Ik1BQSIsInRlc3Rncm91cHMiOiJmYWxzZSIsIm9tbmlwcm9fcm9sZXMiOiJPbW5pUHJvU3VwcG9ydCIsInByZWZlcnJlZF91c2VybmFtZSI6InMyODU1MCIsImdpdmVuX25hbWUiOiJEaW5lc2giLCJtaWRkbGVfbmFtZSI6IiIsImZhbWlseV9uYW1lIjoiUGVrYW50aSIsInBpLnNyaSI6IjFYUkZ1VUFrSWVjT2FxTjRWMWdVS1ZqXzRVcy4uQzZoTiIsIm5vbmNlIjoiNmYxODg4Y2MtNjliYi00YzE0LTljMGYtM2IwMmE5NDg2YThjIn0.ArT3bCoo-XYY9SpbSA36EuhGg1HkXT5lX-ek-cXWe00vjiaSEjupsq5wmx_NhHUlCiG11o01__5s-9CSC9N_G7WJcn7SqyZtUsrJOEwMy7gNPwnCPZQk-NdFPILc8K_Z8gb2vwyB3gnmVmvReJW7eIw6QHAtSwp-ErL8GaqQ-rUX1KMoV10RpzUuS5Vm-GjJEueuf9Soq_cuVXPhIGxU1BWYgbI8iAB_aZwf87gIe8TH92q11ixBl7rKqf_E_E-o8ImcamGGYCDZ97lA48PjTYAJgdM-zd5HSLkXc1bc-qFLzPqrLYv9qTTq8JrNyJRWFpIzehEwH80k1DsMrU8_wQ";

	public RequestSpecification requestspecification() throws IOException {
		if (reqsb == null) {
			PrintStream log = new PrintStream(new FileOutputStream("logging.txt"));
			reqsb = new RequestSpecBuilder().setBaseUri(getGlobalvalue("baseURl"))
					.addFilter(RequestLoggingFilter.logRequestTo(log))
					.addFilter(ResponseLoggingFilter.logResponseTo(log)).setContentType(ContentType.JSON).build();
			return reqsb;
		}
		return reqsb;
	}

	public static String getGlobalvalue(String key) throws IOException {
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream("src\\test\\java\\resources\\global.properties");
		prop.load(fis);
		return prop.getProperty(key);

	}

	public String getJsonpath(Response response, String key) {
		String res = response.asString();
		JsonPath jsp = new JsonPath(res);
		return jsp.get(key).toString();
	}

	public Map<String, String> headerConfig() {
		Map<String, String> map = new HashMap();
		map.put("appId", "01");
		map.put("channelId", "OMP");
		map.put("Content-Type", "application/json");
		map.put("Authorization", Authorization);
		map.put("transactionId", "ohqp8d1ikbi");
		map.put("X-UserContext", X_UserContext);
		map.put("Accept", "application/json");
		return map;

	}
}
