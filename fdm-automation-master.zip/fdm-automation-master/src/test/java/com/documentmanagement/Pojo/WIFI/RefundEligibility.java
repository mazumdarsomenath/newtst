package com.documentmanagement.Pojo.WIFI;
public class RefundEligibility{
    public Object eligibilityDesc;
    public boolean eligibility;
}
