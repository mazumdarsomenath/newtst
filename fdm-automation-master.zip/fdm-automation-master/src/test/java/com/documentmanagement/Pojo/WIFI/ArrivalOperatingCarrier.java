package com.documentmanagement.Pojo.WIFI;
public class ArrivalOperatingCarrier{
    public String boardingPassCarrierName;
    public String carrierCode;
    public String carrierName;
    public String carrierNum;
    public String connectionCarrierOnly;
    public String icaoCarrierCode;
}
