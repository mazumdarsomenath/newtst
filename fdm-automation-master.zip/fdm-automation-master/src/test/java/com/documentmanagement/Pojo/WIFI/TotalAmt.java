package com.documentmanagement.Pojo.WIFI;
public class TotalAmt{
    public CurrencyEquivalentPrice currencyEquivalentPrice;
    public MilesEquivalentPrice milesEquivalentPrice;
}
