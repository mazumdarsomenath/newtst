package com.documentmanagement.Pojo.WIFI;
public class CompensationProperties{
    public Object refundTransactionId;
    public DecisionContext decisionContext;
    public CompensationAdvisory compensationAdvisory;
}
