package com.documentmanagement.Pojo.WIFI;
import java.util.List; 
public class OrderItem{
    public String orderItemNum;
    public String productCategoryId;
    public String orderItemStatusCode;
    public OrderItemPricing orderItemPricing;
    public OverridePrice overridePrice;
    public List<RetailItem> retailItems;
}
