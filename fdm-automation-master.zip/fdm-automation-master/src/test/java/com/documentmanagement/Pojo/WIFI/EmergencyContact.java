package com.documentmanagement.Pojo.WIFI;
public class EmergencyContact{
    public PersonName personName;
    public Phone phone;
}
