package com.documentmanagement.Pojo.WIFI;
import java.util.List; 
public class PassengerPenaltyInformation{
    public Object orderItemPenaltyId;
    public Object passengerId;
    public List<Penalty> penalty;
    public boolean penaltyWaived;
}
