package com.documentmanagement.stepDefinitions;

import com.documentmanagement.GenericMethods.GenericMethods;
import com.documentmanagement.RESTCalls.DocProduceWIFI;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.util.ArrayList;

public class groupingandsequencing_Steps {
    DocProduceWIFI docprd = new DocProduceWIFI();
    GenericMethods gm = new GenericMethods();
    String firstName = null;
    String lastName = null;
    String file_path = null;
    String secondName = null;
    String secondlastName = null;
    String responsedocreferenceid = null;

    @Then("^I enter names for both the passengers in a trip$")
    public void iEnterNamesForBothThePassengersInATrip() throws Exception {
        docprd.setJSONDocprdwifitwopax(firstName, lastName, secondName, secondlastName, file_path);
        docprd.getDocProduceWIFI(file_path, "groupingandsequencing");
    }

    @Given("^I make a post call for two passengers$")
    public String iMakeAPostCallForTwoPassengers() throws Throwable {
        firstName = gm.dynamicNames();
        lastName = gm.dynamicNames();
        secondName = gm.dynamicNames();
        secondlastName = gm.dynamicNames();
        file_path = docprd.createTxtFileFromJson(firstName, "pathToDocProduceWIFIJsontwopax");
        return lastName;
    }

    @When("^I make a post call for (.*) data$")
    public void iMakeAPostCallWithProductIdData(String MKD_PRD_CD) throws Throwable {
        ArrayList<String> al = new ArrayList<String>();
        String[] val = MKD_PRD_CD.split(",");
        for (int i = 0; i < val.length; i++) {
            al = gm.read_xl_particularRow(val[i]);
            docprd.setJSONDocprdwifiFromExcel(i, "pathToDocProduceWIFIJsontwopax", al.get(0), al.get(1), al.get(2), al.get(3), al.get(4), file_path);
            //responsedocreferenceid = docprd.getDocProduceWIFI(file_path, "docProduceWIFI");
        }
        //System.out.println("responsedocreferenceid" + " " + responsedocreferenceid);
    }
}
