package com.documentmanagement.Pojo.WIFI;
public class Penalty{
    public Object pentaltyPrePostFlightCode;
    public Object feeCode;
    public PriceRange priceRange;
}
