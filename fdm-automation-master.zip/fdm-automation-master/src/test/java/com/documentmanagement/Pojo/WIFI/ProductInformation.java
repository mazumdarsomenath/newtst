package com.documentmanagement.Pojo.WIFI;
public class ProductInformation{
    public String productId;
    public String productName;
    public String productDesc;
    public String reasonForIssuanceCode;
    public String reasonForIssuanceSubCode;
    public String productCategoryCode;
    public String productCategoryName;
    public String productSubCategoryCode;
    public String productSubCategoryName;
    public String marketedProductTypeCode;
    public String productTypeCode;
}
