package com.documentmanagement.Pojo.WIFI;
import java.util.List; 
public class RetailItemDefinition{
    public Object retailItemDefinitionId;
    public Object retailItemId;
    public Object retailItemName;
    public Object retailItemDesc;
    public List<Object> additionalRetailItemDesc;
}
