package com.documentmanagement.Pojo.WIFI;
public class MoreInfo{
    public Object code;
    public Object field;
    public Object message;
}
