package com.documentmanagement.Pojo.WIFI;
public class MessageSender{
    public Object senderType;
    public UserInfo userInfo;
}
