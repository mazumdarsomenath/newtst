# Quality Pipelines Deployment Steps

[[_TOC_]]

## Infrastructure Overview

![Architecture Diagram](.images/quality-mvp-overall.png)

## Roles

The roles used in this pattern are configured so that the tooling account ToolingSpokeArtifactDeployer IAM Role is delegated access to assume SpokeArtifactDeployerRole in the target account.

## App Squad Teams will need to have

- 1 Tooling Account ID with access to the `DevToolsUser` Role (Access can be granted via [SailPoint](iam.delta.com))
- List of AWS Spoke Account IDs that require configuration (ex: Dev/SI/PRD/Air4 SI/Air4 Prod)
- Testing framework and test data (*See note below)

>**NOTE: CCoE has provided the infrastructure and support infrastructure to facilitate creating the deployment and testing pipelines, however specific application test data and testing framework must be provided by the application teams.**

### Pre-Installed Tools

It is highly recommended to install this pattern in the [AWS CloudShell](https://aws.amazon.com/cloudshell/). At minimum the following tools need to be installed on the local workstation:

- zip/unzip
- aws cli (v2.0+)
- make (Makefile)

For help installing these tools see [Install-Chocolatey](#install-chocolatey)

## Using Makefiles

Make allows for rapid and consolidated command execution from a workstation into deployment accounts. Before using the Makefile, ensure the variables at the top of the file have the correct path values.
Examples of `make` commands used in this repository:

| Make Command | Description |
|-------------|------------ |
| make whoami | Returns the user you are using to deploy the templates |
| make creds | Moves the downloaded AWS credentials file into the local user .aws directory |
| make check | Checks to see if the stackname already exists in the environment |
| make build | Deploys the CloudFormation stack into the tooling account |
| make update | Updates the stack if changes were made |
| make validate | Validates the template for valid YAML |
| make clean | Deletes the stack |
| make enable-cross-accounts | Deploys the CloudFormation stack into the spoke accounts |
| make update-cross-accounts | Updates the CloudFormation stack in the spoke accounts |
| make clean-cross | Deletes the stack in the spoke accounts |

For more about make see this link: [GNU Make](https://www.gnu.org/software/make/manual/make.html)

## Tooling Account Setup

- [S3 Bucket Setup](https://git.delta.com/ccoe/aws/tooling-account/delta-s3-enterprise-buckets#step-2-deploy-s3-buckets-in-tooling-account) **(Required to be Performed Once Per Tooling Account)** - S3 buckets are deployed into the assocated tooling account to serve as a source for custom actions and report storage
- [Git Custom Action](https://git.delta.com/ccoe/aws/codepipeline-custom-actions/delta-git-clone/codepipeline-custom-action#delta-git-custom-codepipeline-action) **(Required Once if Sourcing from GitLab)** - Custom actions are created in the tooling account and associated application accounts to allow for retrieving code from GitLab and storing it inside of S3.
- [Nexus Custom Action](https://git.delta.com/ccoe/aws/codepipeline-custom-actions/nexus/fetch-raw-hosted-artifact#architecture)**(Required Once if Sourcing from Nexus)** - Custom actions are created in the tooling account and associated application accounts to allow for retrieving artifacts from Cloud Nexus and storing them inside of S3.

## Spoke Account Setup

- [SSM Parameter Setup](https://git.delta.com/ccoe/aws/tooling-account/delta-s3-enterprise-buckets#step-3-deploy-ssm-parameters-to-cross-accounts) **(Required Once in Each Spoke Account)** - AWS SSM Parameters are created in the spoke account to more easily identify and reference the S3 buckets inside the tooling account.
- [Git Custom Action](https://git.delta.com/ccoe/aws/codepipeline-custom-actions/delta-git-clone/codepipeline-custom-action#step-3-deploy-custom-action-to-cross-accounts) **(Required Once if Sourcing from GitLab)** - Custom actions are created in the associated spoke accounts to allow for retrieving code from GitLab and storing it inside of S3.
- [Nexus Custom Action](https://git.delta.com/ccoe/aws/codepipeline-custom-actions/nexus/fetch-raw-hosted-artifact#step-3-deploy-custom-action-to-cross-accounts) **(Required Once if Sourcing from Nexus)** - Custom actions are created in the associated spoke accounts to allow for retrieving artifacts from Cloud Nexus and storing them inside of S3.

## Testing Pipeline Deployment

- [Tooling Account Deployment Pipeline](https://git.delta.com/ccoe/aws/testing-patterns/delta-test-pipeline-deploy) **(Required to Deploy Test Pipelines)** - Pipeline within the tooling account that creates cross account test pipeline in spoke accounts.
- [Functional Test Pipeline](https://git.delta.com/ccoe/aws/testing-patterns/newman-functional-test-pipeline#delta-testing-codepipeline-newmanpostman) - Pipeline within target account that runs test against a running application.

### Install-Chocolatey

If you'd like to run `make` commands locally you must install Chocolatey. Perform the following steps to install the portable version of chocolatey for Windows OS:

```Powershell
# Set directory for installation - Chocolatey does not lock
# down the directory if not the default
$InstallDir='C:\ProgramData\chocoportable'
$env:ChocolateyInstall="$InstallDir"

# If your PowerShell Execution policy is restrictive, you may
# not be able to get around that. Try setting your session to
# Bypass.
Set-ExecutionPolicy Bypass -Scope Process -Force;

# All install options - offline, proxy, etc at
# https://chocolatey.org/install
iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
https://docs.chocolatey.org/en-us/choco/setup#non-administrative-install
```

To use chocolatey to install `make`, use the following command:

```BASH
choco install make
```
[Chocolatey Website](https://docs.chocolatey.org/en-us/choco/setup#non-administrative-install)
