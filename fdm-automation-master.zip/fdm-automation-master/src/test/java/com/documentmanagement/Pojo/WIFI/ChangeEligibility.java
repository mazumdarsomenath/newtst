package com.documentmanagement.Pojo.WIFI;
public class ChangeEligibility{
    public Object eligibilityDesc;
    public boolean eligibility;
}
