package com.documentmanagement.stepDefinitions;

import com.documentmanagement.PageObjecs.AdminTool;
import com.documentmanagement.RESTCalls.CommonPaxDetails;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;


public class Common_Steps {

    SameDayTravelPreVal_Steps sameDay = new SameDayTravelPreVal_Steps();
    CommonPaxDetails com = new CommonPaxDetails();
    public String jsonBody_updated = null;
    String lastname = null;
    String firstname = null;
    WebDriver driver = null;
    AdminTool ad = new AdminTool();

    @And("^I enter passenger details like \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
    public void iEnterPassengerDetailsLike(String LastName, String FirstName, String AccDocNum, String Seg1ofoneArrAirportcode, String Seg1oftwoArrAirportcode, String Seg1ofoneDestAirportcode, String Seg1oftwoDestAirportcode, String Seg1ofonescheduledDepartureLocalTs, String Seg1oftwoscheduledDepartureLocalTs, String Seg1ofonescheduledArrivalLocalTs, String Seg1oftwoscheduledArrivalLocalTs, String Seg1ofonemarketingFlightNum, String Seg1oftwomarketingFlightNum, String Seg1ofoneoperatingFlightNum, String Seg1oftwooperatingFlightNum) throws Throwable {
        jsonBody_updated = com.jsonBody(LastName, FirstName, AccDocNum, Seg1ofoneArrAirportcode, Seg1oftwoArrAirportcode, Seg1ofoneDestAirportcode, Seg1oftwoDestAirportcode, Seg1ofonescheduledDepartureLocalTs, Seg1oftwoscheduledDepartureLocalTs, Seg1ofonescheduledArrivalLocalTs, Seg1oftwoscheduledArrivalLocalTs, Seg1ofonemarketingFlightNum, Seg1oftwomarketingFlightNum, Seg1ofoneoperatingFlightNum, Seg1oftwooperatingFlightNum);
        lastname = LastName;
        firstname = FirstName;
    }

    @When("^I make a post call to given \"([^\"]*)\" for passenger$")
    public void iMakeAPostCallToGivenForPassenger(String endpoint_url) throws Throwable {
        com.postJSON(endpoint_url, jsonBody_updated);
    }

    @Then("^I verify WIFI document with LastName for a single passenger$")
    public void iVerifyWIFIDocumentWithLastNameForPassenger() throws Throwable {
        driver = com.setJSONDocprdsdt(firstname, lastname);
    }

    @And("^I Verify the EMD amount of last coupon item is \"([^\"]*)\" for single passenger$")
    public void iVerifyTheEMDAmountOfFirstRetailsItemIsForSinglePassenger(String Exp_value) throws Throwable {
        String actual_Val = ad.get_currency_last_row(driver);
        Assert.assertEquals("!!!Error!!! Data is not matching", Exp_value, actual_Val);
    }
}