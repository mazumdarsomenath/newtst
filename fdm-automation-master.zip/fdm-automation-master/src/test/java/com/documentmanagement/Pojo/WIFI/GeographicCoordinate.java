package com.documentmanagement.Pojo.WIFI;
public class GeographicCoordinate{
    public String latitudeDegreeNum;
    public String latitudeDirectionCode;
    public String longitudeDegreeNum;
    public String longitudeDirectionCode;
}
