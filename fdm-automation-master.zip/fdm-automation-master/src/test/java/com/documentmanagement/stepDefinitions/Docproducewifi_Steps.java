package com.documentmanagement.stepDefinitions;

import com.documentmanagement.GenericMethods.GenericMethods;
import com.documentmanagement.PageObjecs.AdminTool;
import com.documentmanagement.RESTCalls.DocProduceWIFI;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Docproducewifi_Steps {
    DocProduceWIFI docprd = new DocProduceWIFI();
    GenericMethods gm = new GenericMethods();
    String responsedocreferenceid = null;
    String firstName = null;
    String lastName = null;
    String file_path = null;
    groupingandsequencing_Steps gp_steps = new groupingandsequencing_Steps();


    @When("^I make a post call with ([^\"]*)$")
    public void iMakeAPostCallWith(String MKD_PRD_CD) throws Throwable {
        ArrayList<String> al = new ArrayList<String>();
        al = gm.read_xl_particularRow(MKD_PRD_CD);
        docprd.setJSONDocprdwifiFromExcel(0, "pathToDocProduceWIFIJson", al.get(0), al.get(1), al.get(2), al.get(3), al.get(4), file_path);
        responsedocreferenceid = docprd.getDocProduceWIFI(file_path, "docProduceWIFI");
        System.out.println("responsedocreferenceid" + " " + responsedocreferenceid);
    }

    @Then("^I verify WIFI document with RFISC sub code W(\\d+) \\(WIFI Flight Leg Pass\\) and CC FOP with LastName$")
    public void iVerifyWIFIDocumentWithRFISCSubCodeWWIFIFlightLegPassAndCCFOP(int arg0) throws Throwable {

        gm.launchEMD_plus();
        AdminTool ad = new AdminTool();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MMM-yy");
        LocalDateTime now = LocalDateTime.now();
        String today_date = dtf.format(now);
        ad.enter_lastname(gp_steps.iMakeAPostCallForTwoPassengers());
        ad.enter_issuedaterange(today_date);
        ad.enter_issuedaterange1(today_date);
        ad.click_find();
        Thread.sleep(3000);
        String passname = ad.getPassengerName();
        String docnum = ad.getDocumentNumber();
        gm.writeExcel(passname, docnum);
        //gm.teardown();
    }

    @Given("^a request with ([^\"]*) with firstname and lastname$")
    public void aRequestWith(String pri) throws Throwable {
        firstName = gm.dynamicNames();
        lastName = gm.dynamicNames();
        file_path = docprd.createTxtFileFromJson(firstName, "pathToDocProduceWIFIJson");
        docprd.setJSONDocprdwifi("pathToDocProduceWIFIJson", pri, firstName, lastName, file_path);
    }
}