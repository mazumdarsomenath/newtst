package com.documentmanagement.Pojo.WIFI;
import java.util.List; 
public class RemarksList{
    public Object remarkTypeCode;
    public List<Remark> remarks;
}
