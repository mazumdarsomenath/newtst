package com.documentmanagement.Runner;

import java.util.HashMap;

import org.junit.AfterClass;
import org.junit.runner.RunWith;
import com.cucumber.listener.Reporter;
import com.documentmanagement.handlers.ReadProperties;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
        monochrome = true,
        features = "src/test/resources/features",
        tags = {"@test1234"},
        glue = {"com.documentmanagement.stepDefinitions"},
        plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html"}
)


public class TestRunner {

    static HashMap<String, String> ResMapList = ReadProperties
            .getAllValue(".\\src\\main\\resources\\Configuration.properties");

    @AfterClass
    public static void writeExtentReport() {

        Reporter.loadXMLConfig(ResMapList.get("reportConfigPath"));
        Reporter.setSystemInfo("User Name", System.getProperty("user.name"));
        //Reporter.loadXMLConfig(new File(FileReaderManager.getInstance().getConfigReader().getReportConfigPath()));
        Reporter.setSystemInfo("Time Zone", System.getProperty("user.timezone"));
        Reporter.setSystemInfo("Machine", System.getProperty("os.name") + "64 Bit");
        Reporter.setSystemInfo("rest-assured", "3.0.0");
        Reporter.setSystemInfo("Maven", "3.5.1");
        Reporter.setSystemInfo("Java Version", "1.8.0_151");
    }
}