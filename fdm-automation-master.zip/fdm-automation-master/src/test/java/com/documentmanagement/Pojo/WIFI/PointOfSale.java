package com.documentmanagement.Pojo.WIFI;
public class PointOfSale{
    public String countryCode;
    public Object officeTypeCode;
    public String pointOfSaleCityCode;
    public String pointOfSaleId;
    public boolean soldByTravelAgency;
    public Object deviceTypeText;
    public Object ipAddressText;
    public Object browserTypeText;
    public Object vdnCode;
    public String customerId;
    public Object digitalSaleMetadataText;
}
