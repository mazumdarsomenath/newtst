package com.documentmanagement.Pojo.WIFI;
public class Remark{
    public Object carrierCode;
    public Object remarkTypeCode;
    public Object messageText;
    public Object remarkLineNum;
}
