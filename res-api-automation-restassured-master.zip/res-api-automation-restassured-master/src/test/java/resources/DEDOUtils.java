package resources;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DEDOUtils {
	String createdPNR;
	String custLastName;
	String skymileNum;
	RequestSpecification request;
	String AuthorizationValue = "eyJhbGciOiJSUzI1NiIsImtpZCI6ImsxIiwicGkuYXRtIjoiMyJ9.eyJzY29wZSI6WyJvcGVuaWQiLCJwcm9maWxlIiwib21uaXByb3JvbGVzIl0sImNsaWVudF9pZCI6Im9tbmlwcm9fb2lkYyIsImdyYW50X2lkIjoiaW9HdGk1TFAybm1tWTBmblIzZE1YMjZNc0FXVzNkQ1AiLCJpc3MiOiJodHRwczovL3NzYWFzaS5kZWx0YS5jb20iLCJqdGkiOiJ4OERDa09QMGRoVjlUaTNvR0Izd1hhSzRGTGp2Ymo0QiIsImRsbWlkIjoiMjI4MjE3OSIsIm9yZ05hbWUiOiJEZWx0YSBBaXIgTGluZXMgKFNJKSIsInN1YmplY3QiOiIyMjgyMTc5IiwiZXhwIjoxNjI3NDgwODI2fQ.MNgtc6M4JKLsjCF7FE1clmkW_qSK-G7CtzjjVl1wnke8_5oyDCYwVg-z0ECjz23o3zwe-FEBwCqdfWO4f1Btc6jxABq_s7y0SmrjRGIKw_sTHN4ZcCQq6xVlVw4zRlM3ZV6CyvdRvwXjda7ks67LEPTQpeI88Gqn292XJftUTAZ0fgwv-3cCtGd6fSzCYdLQTpTV6RtHvlNyyVagU5lsMmClDwk10FdBlwRysL94GpNLNO1hPE-xfOC2fz2XPQGGLZ7mccxQjPIsNIihlwp7oCqyASXXWLknMrg0LASjnEfBIKs3wvqEKBUxmCC1YEuEJzXZsaO9yQ-SipwUfnqMng";
	String UserContextValue = "eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ245M2Jza3ZGNkFkcnFaU2IwLWFnZVFKcyJ9.eyJzdWIiOiIyMjgyMTc5IiwiYXVkIjoib21uaXByb19vaWRjIiwianRpIjoiT3lrUXhlQWNrMTF4dm10Z2Frakx0RSIsImlzcyI6Imh0dHBzOi8vc3NhYXNpLmRlbHRhLmNvbSIsImlhdCI6MTYyNzQ3MzYyNiwiZXhwIjoxNjI3NDczOTI2LCJhdXRoX3RpbWUiOjE2Mjc0NzM2MjQsImRsbWlkIjoiMjI4MjE3OSIsInVwZGF0ZWRfYXQiOjE2Mjc0NzE2NzEsInBwcl9udW1iZXIiOiIwMDIyODIxNzkiLCJuYW1lIjoiQmVoZXJhLCBOaXJub3kgTiIsInN0YXRpb24iOiJNQUEiLCJ0ZXN0Z3JvdXBzIjoiZmFsc2UiLCJvbW5pcHJvX3JvbGVzIjpbIk9tbmlQcm9VdGlsaXRpZXNBbGwiLCJPbW5pUHJvU3ltcGhvbnlBbGwiLCJPbW5pUHJvU3ltcGhvbnlQaWxvdCIsIk9tbmlQcm9TdXBwb3J0IiwiT21uaVByb1BpbG90Il0sInByZWZlcnJlZF91c2VybmFtZSI6Inc4MjE3OSIsImdpdmVuX25hbWUiOiJOaXJub3kiLCJtaWRkbGVfbmFtZSI6Ik5pbWVzaCIsImZhbWlseV9uYW1lIjoiQmVoZXJhIiwicGkuc3JpIjoic3d0STdETkhiYlNqM3hJUFRKcTJWdlFMSDFzLi5BVWJYIiwibm9uY2UiOiI2ZjE4ODhjYy02OWJiLTRjMTQtOWMwZi0zYjAyYTk0ODZhOGMifQ.mBJQtYHPrYdFusr6w0_2R8xdI7xx_ZhGmAg2DZuMCn2WnDRdAIXPV3qjStlU2t0YYOP2iBR-hqDr8YqI_wN_CtTsrkd6pNnnbnCWIwpUheekEzzzbJpdLxfSfaAEo4RLYpENRyAu_3XUuu_z4LL8Hho4gTDsKQS-R73nxo2Mz4JHQfkUfnA7yzVf8QY24ADmeEJtvgAVx1-i8rElcpgpIMbig_sPjNj_vnoaDuM0M3hzbcSdqzZzM5w_HnbTu_qa-9lpROnPaAOZUN1GLGh_TjFrwI2ULKFy49px8z5idi_QfOUD6PyaTfy490WMetSIz55errBB7v90zt25RpmCgQ";

	@Test
	public void generateTestData() throws IOException {
		RestAssured.baseURI = "http://sxpda10086.delta.com:30387";

//		String requestBody = "{\"testCaseId\": \"11\",\r\n" + "                \"date\":\"23JUL\",\r\n"
//				+ "                \"transactionId\":\"UrDeltaDeDO\",\r\n"
//				+ "                \"clientId\": \"SNAPP\",\r\n" + "                \"testLab\": \"TSBB\",\r\n"
//				+ "                \"routes\": \"MSP,ATL\",\r\n"
//				+ "                \"frequentFlyerNumber\": \"8006270311\"}";

		request = RestAssured.given();

		Response response = request.header("Content-Type", "application/json").header("Accept", "application/json")
				.and().body(new File("src\\test\\java\\testData\\DEDORevenuePnr.json")).when()
				.post("/DedoMenaEngine/testdata").then().extract().response();

		Assert.assertEquals(200, response.statusCode());

		String responseBody = response.getBody().asString();
		System.out.println(responseBody);
		createdPNR = response.getBody().path("testCaseId11.DLMPlugin.pnr[0]");
		custLastName = response.getBody().path("testCaseId11.DLMPlugin.responseObject.passenger[0].lastName");
		skymileNum = response.getBody().path("testCaseId11.DLMPlugin.responseObject.frequentFlyer[0].accountNumber");

		System.out.println("PNR Generated from DEDO API is :" + " " + createdPNR);
		System.out.println("Last Name Fetched from DEDO API is :" + " " + custLastName);

		FileWriter file = new FileWriter("src\\test\\java\\testData\\DEDOResponse.json");
		file.write(response.prettyPrint());
		file.flush();
		file.close();

	}

	public void updateTestData() throws IOException {
		File filePath = new File("src\\test\\java\\testData\\LastNamePnrRQ.json");

		try {
			// read the json file
			FileReader reader = new FileReader(filePath);

			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);

			JSONObject searchCritObj = (JSONObject) jsonObject.get("searchByPnrCriteria");

			searchCritObj.put("recordLocatorId", createdPNR);
			searchCritObj.put("lastName", custLastName);

			System.out.println(jsonObject);

			FileWriter file = new FileWriter("src\\test\\java\\testData\\LastNamePnrRQ.json");
			file.write(jsonObject.toJSONString());
			file.flush();
			file.close();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (ParseException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}

	}

	public void omp_search_lastname_pnr() throws IOException {

		RestAssured.baseURI = "https://omnipro-dvla.delta.com";

//		String requestBody = "{\r\n" + "    \"searchByPnrCriteria\": {\r\n" + "        \"recordLocatorId\": "
//				+ createdPNR + ",\r\n" + "        \"lastName\": " + custLastName + "\r\n" + "    }\r\n" + "}";

//		String requestBody = "{\r\n" + 
//				"    \"searchByPnrCriteria\": {\r\n" + 
//				"        \"recordLocatorId\": "+createdPNR+",\r\n" + 
//				"        \"lastName\": \"OLIVE\"\r\n" + 
//				"    }\r\n" + 
//				"}";

		request = RestAssured.given().relaxedHTTPSValidation();

		Response response = request.header("Content-Type", "application/json").header("Accept", "application/json")
				.header("X-UserContext", UserContextValue).header("Authorization", AuthorizationValue)
				.header("channelId", "OMP").and().body(new File("src\\test\\java\\testData\\LastNamePnrRQ.json")).when()
				.post("/loyalty/v1/search").then().extract().response();

		Assert.assertEquals(200, response.statusCode());

		System.out.println("PNR Generated from DEDO API is :" + " " + createdPNR);
		System.out.println("Last Name Fetched from DEDO API is :" + " " + custLastName);

		String responseBody = response.getBody().asString();
		System.out.println(responseBody);
	}
	
//	public void verify_skymile_num() throws IOException {
//		
//	}

}
