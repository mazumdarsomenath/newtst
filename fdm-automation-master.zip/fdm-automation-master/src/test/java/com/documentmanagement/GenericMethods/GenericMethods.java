package com.documentmanagement.GenericMethods;

import com.documentmanagement.handlers.ReadProperties;
import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class GenericMethods {

    HashMap<String, String> ResMapList = ReadProperties
            .getAllValue(".\\src\\main\\resources\\Configuration.properties");

    //String filename = new SimpleDateFormat("yyyyMMddHHmmss'.csv'").format(new Date());
    //Admin tool web app
    public static WebDriver driver = null;
    public static WebDriverWait waitVar = null;

    public ArrayList<String> read_xl() {
        ArrayList<String> al = new ArrayList<String>();
        try {
            FileInputStream file = new FileInputStream(new File(ResMapList.get("pathToExcel")));
            XSSFWorkbook wb = new XSSFWorkbook(file);
            XSSFSheet sheet = wb.getSheetAt(0);
            //double d;
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                String docVal = sheet.getRow(i).getCell(0).getRawValue();//evaluating cell type
                al.add(docVal);
            }
            /* Writing into excel under Identity column for respective credentials */
            FileOutputStream outFile = new FileOutputStream(new File(ResMapList.get("pathToExcel")));
            wb.write(outFile);
            file.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return al;
    }

    public void writeExcel(String passenger_name, String document_number) {
        try {
            FileInputStream file = new FileInputStream(new File(ResMapList.get("pathToWriteExcelWIFIResults")));
            XSSFWorkbook wb = new XSSFWorkbook(file);
            XSSFSheet sheet = wb.getSheetAt(0);
            //Row r = sheet.createRow(1);
            for (int i = sheet.getLastRowNum(); i <= sheet.getLastRowNum() + 1; i++) {
                //if (sheet.getRow(i+1) == null) {
                // This cell is empty
                Row r = sheet.createRow(i + 1);
                r.createCell(0).setCellValue(passenger_name);
                r.createCell(1).setCellValue(document_number);
                //}
                break;
            }
            FileOutputStream outFile = new FileOutputStream(new File(ResMapList.get("pathToWriteExcelWIFIResults")));
            wb.write(outFile);
            file.close();
            System.out.println("Your excel file has been generated!");

        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public ArrayList<String> read_xl_particularRow(String name) throws IOException {
        ArrayList<String> al = new ArrayList<String>();
        try {
            FileInputStream file = new FileInputStream(new File(ResMapList.get("PathTo_MKD_PRD_DL_SI")));
            XSSFWorkbook wb = new XSSFWorkbook(file);
            XSSFSheet sheet = wb.getSheetAt(0);
            //double d;
            int index = 0;
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                if (name.equalsIgnoreCase(sheet.getRow(i).getCell(0).toString())) {
                    index = i;
                    break;
                }
            }
            al.add((sheet.getRow(index).getCell(0)).toString());
            al.add((sheet.getRow(index).getCell(1)).toString());
            al.add((sheet.getRow(index).getCell(2)).toString());
            al.add((sheet.getRow(index).getCell(5)).toString());
            al.add((sheet.getRow(index).getCell(11)).toString());
            FileOutputStream outFile = new FileOutputStream(new File(ResMapList.get("pathToExcel")));
            wb.write(outFile);
            file.close();

        } catch (Exception ex) {
            System.out.println(ex);
        }
        return al;
    }


    public WebDriver launchEMD_plus() throws InterruptedException {
        if ((ResMapList.get("browser")).equalsIgnoreCase("chrome")) {
            System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
            driver = new ChromeDriver();
            driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.get("http://eddwd0101naa.delta.com:17063/adminTool/searchEMD.action");
            Thread.sleep(3000);
        } else {
            System.setProperty("webdriver.edge.driver", "drivers/msedgedriver.exe");
            // Start Edge Session
            WebDriver driver = new EdgeDriver();
            driver.get("http://eddwd0101naa.delta.com:17063/adminTool/searchEMD.action");
            Thread.sleep(3000);
        }
        return driver;
    }

    public void teardown() {
        if (driver != null) {
            System.out.println("Closing browser");
            driver.quit();
        }
    }

    public void readTextFile(String oldLine, String newLine, String newFilePath) {
        //Instantiating the File class
        try {
            //String filePath = ResMapList.get("pathtodocproducewifitext");
            //Instantiating the Scanner class to read the file
            Scanner sc = new Scanner(new File(newFilePath));
            //instantiating the StringBuffer class
            StringBuffer buffer = new StringBuffer();
            //Reading lines of the file and appending them to StringBuffer
            while (sc.hasNextLine()) {
                buffer.append(sc.nextLine() + System.lineSeparator());
            }
            String fileContents = buffer.toString();

            //closing the Scanner object
            sc.close();
            //Replacing the old line with new line
            fileContents = fileContents.replaceAll(oldLine, newLine);
            //instantiating the FileWriter class
            FileWriter writer = null;
            writer = new FileWriter(newFilePath);
            System.out.println("");
            System.out.println("new data: " + fileContents);
            writer.append(fileContents);
            writer.flush();

            //System.out.println("Contents of the file: " + fileContents);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String dynamicNames() {
        // create StringBuffer size of AlphaNumericString
        StringBuilder sb = new StringBuilder(7);
        try {
            String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            for (int i = 0; i < 7; i++) {
                // generate a random number between
                // 0 to AlphaNumericString variable length
                int index
                        = (int) (AlphaNumericString.length()
                        * Math.random());
                // add Character one by one in end of sb
                sb.append(AlphaNumericString
                        .charAt(index));
            }
            System.out.println(sb.toString());
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return sb.toString();
    }

    public String getUUID() {
        UUID uuid = UUID.randomUUID();
        return uuid.toString();
    }

    public void takeScreenShot(WebDriver driver) throws Exception {
        if (driver == null || driver.toString().contains("(null)")) {
            return;
        } else {

        }
        try {
            TakesScreenshot ts = (TakesScreenshot) driver;
            File source = ts.getScreenshotAs(OutputType.FILE);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HHmmss");
            LocalDateTime now = LocalDateTime.now();
            String downloadPath = "./fdm_Screenshots";
            File file = new File(downloadPath);
            if (!file.exists()) {
                if (file.mkdir()) {
                    System.out.println("Directory is created!");
                } else {
                    System.out.println("Directory already exist");
                }
            }
            FileUtils.copyFile(source, new File(downloadPath + "/fdm_finance_UI_" + dtf.format(now) + ".png"));
            System.out.println("the Screenshot is taken");
            //driver.quit();
        } catch (Exception e) {
            throw e;
        }
    }

    public static String getScreenShot(WebDriver driver) {
        String destination = null;
        try {
            String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
            TakesScreenshot ts = (TakesScreenshot) driver;
            File source = ts.getScreenshotAs(OutputType.FILE);

            destination = System.getProperty("user.dir") + "/ScreenShots/" + "fdm_finance_UI_" + dateName + ".png";
            File finalDestination = new File(destination);
            FileUtils.copyFile(source, finalDestination);
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return destination;
    }



}