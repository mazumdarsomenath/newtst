package com.documentmanagement.Pojo.WIFI;
import java.util.List; 
public class OrderDataList{
    public List<Customer> customers;
    public List<PassengerItinerarySegment> passengerItinerarySegment;
    public List<Trip> trips;
    public List<RetailItemDefinition> retailItemDefinitions;
    public List<ProductCategory> productCategories;
    public List<SpecialServiceInfoList> specialServiceInfoList;
    public List<RemarksList> remarksList;
    public List<HistoryInfoList> historyInfoList;
    public List<OrderItemEligibility> orderItemEligibilities;
    public List<PassengerPenaltyInformation> passengerPenaltyInformations;
    public CompensationProperties compensationProperties;
    public List<UnaccompaniedMinorList> unaccompaniedMinorList;
}
