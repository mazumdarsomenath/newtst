package com.documentmanagement.Pojo.WIFI;
public class ScheduleChangeEligibility{
    public Object eligibilityDesc;
    public boolean eligibility;
}
