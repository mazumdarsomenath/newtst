package com.documentmanagement.stepDefinitions;

import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import com.documentmanagement.GenericMethods.GenericMethods;
import com.documentmanagement.RESTCalls.DocumentManagement;
import com.documentmanagement.handlers.EncryptionDecryption;
import com.documentmanagement.handlers.ReadProperties;

import com.opencsv.CSVWriter;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;

public class Computeexpirationdate_Steps {

    DocumentManagement Lgpage = new DocumentManagement();
    GenericMethods gm = new GenericMethods();
    String accesstoken;
    ArrayList<String> al = new ArrayList<String>();
    String filename = new SimpleDateFormat("yyyyMMddHHmmss'.csv'").format(new Date());
    public String csv_filepath = ("src/test/resources/reports/CSV_file_testResults" + filename);

    @Given("^a Passenger Ticket without an expiration date$")
    public void a_Passenger_Ticket_plated_without_an_expiration_date() throws Throwable {
        accesstoken = Lgpage.getAccessToken();
    }

    @When("^expiration date is Null in display response$")
    public void expiration_date_is_Null_in_display_response() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        al = gm.read_xl();
    }

    @Then("^verify that computed date is one year from the issueLocalDate\\.$")
    public void verify_that_computed_date_is_one_year_from_the_issueLocalDate() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String[] accountDocNum = new String[al.size()];
        String[] isslocDate = new String[al.size()];
        String[] expDate = new String[al.size()];
        String yearLater;
        LocalDate localDate;

        for (int i = 0; i <= al.size() - 1; i++) {
            accountDocNum[i] = Lgpage.getAccountDocNum(al.get(i), accesstoken);
            isslocDate[i] = Lgpage.getLocalDate(al.get(i), accesstoken);
            expDate[i] = Lgpage.getExpDate(al.get(i), accesstoken);
        }

        FileWriter outputfile = new FileWriter(csv_filepath);
        // create CSVWriter object filewriter object as parameter
        CSVWriter writer = new CSVWriter(outputfile);
        // adding header to csv
        String[] header = {"accountableDocumentNum", "expirationDate", "issueLocalDate"};
        writer.writeNext(header);

        for (int i = 0; i <= al.size() - 1; i++) {
            String[] data1 = {accountDocNum[i], isslocDate[i], expDate[i]};
            writer.writeNext(data1);
        }
        // closing writer connection
        writer.close();

        String pattern = "yyyy-MM-dd";
        DateTimeFormatter expectedexpirationdate = DateTimeFormatter.ofPattern(pattern);
        for (int i = 0; i <= al.size() - 1; i++) {
            if ((isslocDate[i]).equals("2020-02-29")) {
                localDate = LocalDate.parse((isslocDate[i]), expectedexpirationdate);
                yearLater = (localDate.plusYears(1).plusDays(1)).toString();
            } else {
                localDate = LocalDate.parse((isslocDate[i]), expectedexpirationdate);
                yearLater = (localDate.plusYears(1)).toString();
            }
            Assert.assertEquals("!!!Error!!!, Data mismatch for account doc number " + accountDocNum[i], expDate[i], yearLater);
        }
    }
}