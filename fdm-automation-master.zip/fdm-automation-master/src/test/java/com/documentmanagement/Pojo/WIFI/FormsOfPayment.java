package com.documentmanagement.Pojo.WIFI;
public class FormsOfPayment{
    public String getPaymentReferenceId() {
        return paymentReferenceId;
    }

    public void setPaymentReferenceId(String paymentReferenceId) {
        this.paymentReferenceId = paymentReferenceId;
    }

    public String paymentReferenceId;
    public PaymentMethod paymentMethod;

}
