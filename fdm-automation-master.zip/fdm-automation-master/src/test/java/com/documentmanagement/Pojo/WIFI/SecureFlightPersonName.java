package com.documentmanagement.Pojo.WIFI;
public class SecureFlightPersonName{
    public Object firstName;
    public Object lastName;
    public Object middleName;
    public Object namePrefixCode;
    public Object nameSuffixCode;
    public Object nameRemarks;
}
