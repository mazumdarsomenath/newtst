package com.documentmanagement.Pojo.WIFI;
public class Redress{
    public Object redressNum;
    public Object programName;
    public String countryCode;
}
