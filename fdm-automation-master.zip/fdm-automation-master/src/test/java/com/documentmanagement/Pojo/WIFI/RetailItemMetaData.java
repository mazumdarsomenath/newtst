package com.documentmanagement.Pojo.WIFI;
public class RetailItemMetaData{
    public ProductInformation productInformation;
}
