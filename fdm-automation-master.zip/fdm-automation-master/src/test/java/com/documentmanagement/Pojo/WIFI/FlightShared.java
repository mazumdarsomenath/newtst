package com.documentmanagement.Pojo.WIFI;

import java.util.Date;

public class FlightShared{
    public String originAirportCode;
    public String destinationAirportCode;
    public String operatingCarrierCode;
    public String marketingCarrierCode;
    public String operatingFlightNum;
    public Date scheduledDepartureLocalTs;
}
