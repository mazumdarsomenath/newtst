package resources;

public enum APIResources {
	FaresSearchAPI("/utilitiessvc/v1/search/standalone"), MilesSearchAPI("/utilitiessvc/v1/fareMiles/standalone"),
	DEDOApi("/DedoMenaEngine/testdata"),CustomerProfile("/customer/v1/profile"),Ecredit("/cevc/v1/ecredit"),
	Ecertificate("/cevc/v1/ecertificate"),Evoucher("/cevc/v1/evoucher"),
	CompensationHistory("/cevc/v1/compensationhistory"),Activities("/loyalty/v1/activities"),
	UpcomingTrips("/trips/v1/upcomingtrips"),PastTrips("/trips/v1/pasttrips"),
	Allowance("/baggage/v1/allowance");

	private String resource;

	APIResources(String resource) {
		this.resource = resource;
	}

	public String getResource() {
		return resource;

	}
}
