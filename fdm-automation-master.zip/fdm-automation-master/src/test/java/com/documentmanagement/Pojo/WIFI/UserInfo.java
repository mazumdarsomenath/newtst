package com.documentmanagement.Pojo.WIFI;
public class UserInfo{
    public String carrierCode;
    public String applicationChannelName;
    public String cityCode;
    public Object userId;
    public Object passwordText;
    public Object agentDutyCode;
    public Object poolName;
    public String testLabName;
    public Object roleId;
}
