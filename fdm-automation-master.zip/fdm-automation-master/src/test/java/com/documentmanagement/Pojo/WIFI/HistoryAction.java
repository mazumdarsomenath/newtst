package com.documentmanagement.Pojo.WIFI;
public class HistoryAction{
    public Object actionCode;
    public Object actionText;
}
