package com.documentmanagement.Pojo.WIFI;
public class TotalAirTime{
    public int dayCnt;
    public int hourCnt;
    public int minuteCnt;
}
