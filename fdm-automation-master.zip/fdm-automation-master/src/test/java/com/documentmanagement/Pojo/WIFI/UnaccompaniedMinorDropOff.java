package com.documentmanagement.Pojo.WIFI;
import com.fasterxml.jackson.annotation.JsonProperty; 
import java.util.List; 
public class UnaccompaniedMinorDropOff{
    public PersonName personName;
    @JsonProperty("Address") 
    public Address address;
    public List<Phone> phone;
    public List<Object> passengerIds;
}
