package com.documentmanagement.Pojo.WIFI;
public class PaymentMethod{
    public String paymentMethodTypeName;
    public PaymentCard paymentCard;
}
