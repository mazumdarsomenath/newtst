package com.documentmanagement.Pojo.WIFI;
public class UnaccompaniedMinor{
    public Object passengerId;
    public int passengerAge;
}
