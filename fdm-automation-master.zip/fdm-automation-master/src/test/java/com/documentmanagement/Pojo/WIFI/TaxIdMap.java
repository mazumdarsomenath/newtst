package com.documentmanagement.Pojo.WIFI;
public class TaxIdMap{
    public Object additionalProp1;
    public Object additionalProp2;
    public Object additionalProp3;
}
