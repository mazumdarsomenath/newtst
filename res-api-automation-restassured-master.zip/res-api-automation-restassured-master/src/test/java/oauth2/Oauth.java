package oauth2;

public class Oauth {

}
