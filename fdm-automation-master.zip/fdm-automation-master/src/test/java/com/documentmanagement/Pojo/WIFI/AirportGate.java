package com.documentmanagement.Pojo.WIFI;
public class AirportGate{
    public String gateId;
}
