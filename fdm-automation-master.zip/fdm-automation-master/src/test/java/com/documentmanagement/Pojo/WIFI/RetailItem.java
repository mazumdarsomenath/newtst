package com.documentmanagement.Pojo.WIFI;
import java.util.List; 
public class RetailItem{
    public String retailItemId;
    public String retailItemDefinitionId;
    public RetailItemPricing retailItemPricing;
    public List<String> tripIds;
    public List<String> passengerRefIds;
    public List<String> flightSegmentIds;
    public RetailItemMetaData retailItemMetaData;
}
