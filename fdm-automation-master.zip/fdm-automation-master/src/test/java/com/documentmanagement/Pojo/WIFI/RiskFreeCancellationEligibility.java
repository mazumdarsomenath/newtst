package com.documentmanagement.Pojo.WIFI;
public class RiskFreeCancellationEligibility{
    public Object eligibilityDesc;
    public boolean eligibility;
}
