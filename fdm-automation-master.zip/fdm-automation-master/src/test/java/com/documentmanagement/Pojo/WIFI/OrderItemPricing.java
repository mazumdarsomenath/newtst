package com.documentmanagement.Pojo.WIFI;
public class OrderItemPricing{
    public TotalAmt totalAmt;
    public BaseAmt baseAmt;
}
