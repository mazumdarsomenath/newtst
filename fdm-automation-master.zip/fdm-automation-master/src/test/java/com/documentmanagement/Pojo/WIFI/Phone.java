package com.documentmanagement.Pojo.WIFI;
public class Phone{
    public String contactOfCode;
    public Object countryCallingCode;
    public Object phoneAreaNum;
    public Object phoneContactMethodCode;
    public Object phoneExtensionNum;
    public Object phoneNum;
}
