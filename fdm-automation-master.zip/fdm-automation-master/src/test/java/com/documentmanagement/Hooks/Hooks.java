package com.documentmanagement.Hooks;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;



import com.cucumber.listener.Reporter;
import com.documentmanagement.GenericMethods.GenericMethods;
import com.google.common.io.Files;
import com.mongodb.MapReduceCommand.OutputType;
import cucumber.api.Scenario;
import cucumber.api.java.Before;


import cucumber.api.Scenario;
import cucumber.api.java.After;
import org.openqa.selenium.WebDriver;

public class Hooks {
 
	GenericMethods gm = new GenericMethods();
 WebDriver driver ;
	
 @Before
 public void beforeScenario(Scenario scenario) throws InterruptedException {
     Reporter.assignAuthor("Shamili Automation Framework");
 }
 
 @After(order = 0)
 public void afterScenario(Scenario scenario) throws IOException {
 if (scenario.isFailed()) {

 }
 }
}