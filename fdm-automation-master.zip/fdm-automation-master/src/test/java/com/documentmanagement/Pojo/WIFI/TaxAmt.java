package com.documentmanagement.Pojo.WIFI;
public class TaxAmt{
    public CurrencyEquivalentPrice currencyEquivalentPrice;
    public MilesEquivalentPrice milesEquivalentPrice;
}
