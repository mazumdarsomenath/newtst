package com.documentmanagement.Pojo.WIFI;
public class DestinationAirportGroup{
    public String airportGroupId;
}
