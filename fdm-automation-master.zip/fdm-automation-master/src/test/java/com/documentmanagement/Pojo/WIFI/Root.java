package com.documentmanagement.Pojo.WIFI;
public class Root{
    public Order order;
    public MessageSender messageSender;
}
