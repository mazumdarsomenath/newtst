package com.documentmanagement.Pojo.WIFI;
import java.util.List; 
public class TaxSummary{
    public TotalTaxAmt totalTaxAmt;
    public List<Tax> taxes;
}
