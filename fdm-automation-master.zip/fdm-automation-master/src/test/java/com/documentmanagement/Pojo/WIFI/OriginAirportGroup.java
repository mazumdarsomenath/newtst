package com.documentmanagement.Pojo.WIFI;
public class OriginAirportGroup{
    public String airportGroupId;
}
