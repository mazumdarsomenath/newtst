package com.documentmanagement.Pojo.WIFI;
public class BaseAmt{
    public CurrencyEquivalentPrice currencyEquivalentPrice;
    public MilesEquivalentPrice milesEquivalentPrice;
}
