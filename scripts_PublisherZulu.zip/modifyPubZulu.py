import sys

pubZuluPath = sys.argv[1]
odeSchemasPath = sys.argv[2]


fin = open("PublisherZulu.exe.config", "rt")
data = fin.read()
data = data.replace('absolutePathForPublisherZulu', pubZuluPath)
fin.close()
fin = open("PublisherZulu.exe.config", "wt")
fin.write(data)
fin.close()

fin = open("PublisherZulu.xml", "rt")
data = fin.read()
data = data.replace("absolutePathForode-schemas", odeSchemasPath)
fin.close()
fin = open("PublisherZulu.xml", "wt")
fin.write(data)
fin.close()

fin = open("beanpolicies.xml", "rt")
data = fin.read()
data = data.replace("absolutePathForode-schemas", odeSchemasPath)
fin.close()
fin = open("beanpolicies.xml", "wt")
fin.write(data)
fin.close()