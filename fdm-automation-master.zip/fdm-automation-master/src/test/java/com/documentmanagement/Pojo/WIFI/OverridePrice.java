package com.documentmanagement.Pojo.WIFI;
public class OverridePrice{
}
