package com.documentmanagement.Pojo.WIFI;
public class CurrencyEquivalentPrice{
    public int decimalPrecisionCnt;
    public int currencyAmt;
    public String currencyCode;
    public Object countryCode;
}
