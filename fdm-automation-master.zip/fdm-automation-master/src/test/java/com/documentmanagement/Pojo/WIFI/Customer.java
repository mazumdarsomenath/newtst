package com.documentmanagement.Pojo.WIFI;
import java.util.List; 
public class Customer{
    public Object adultWithInfantPassengerId;
    public List<Object> affiliationCodes;
    public String birthDate;
    public String customerId;
    public String emailAdr;

    public String getEmailAdr() {
        return emailAdr;
    }

    public void setEmailAdr(String emailAdr) {
        this.emailAdr = emailAdr;
    }

    public EmergencyContact emergencyContact;
    public Object firstNameNum;
    public int firstTravelDateAgeNum;
    public Object genderCode;
    public KnownTraveler knownTraveler;
    public Object lastNameNum;
    public int lastTravelDateAgeNum;
    public LoyaltyMember loyaltyMember;
    public String passengerId;
    public Object persistentCustomerId;
    public Object passengerTypeCode;
    public PersonName personName;
    public List<Phone> phones;
    public Redress redress;
    public SecureFlightPersonName secureFlightPersonName;
    public List<TravelDocument> travelDocuments;
    public TaxIdMap taxIdMap;
    public int currentAgeNum;
    public Object nameNum;
    public Object extendedPassengerTypeCode;
    public Object passengerTypeCodeAgeNum;
    public Object transientCustomerId;


}
