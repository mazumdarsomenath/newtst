package com.documentmanagement.Pojo.WIFI;
import java.util.List; 
public class AirportTerminal{
    public List<AirportGate> airportGates;
    public String noTerminalFound;
    public String terminalId;
    public String terminalName;
}
