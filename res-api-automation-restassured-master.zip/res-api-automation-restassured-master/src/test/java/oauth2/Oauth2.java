package oauth2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;

public class Oauth2 {

	/*
	 * 
	 * Response response1 = RestAssured.given().auth().oauth2(token)
	 * .post("http://coop.apps.symfonycasts.com/api/1039/chickens-feed");
	 * System.out.println("status code is " + response.getStatusCode());
	 * System.out.println("status code is " + response.getBody().asString());
	 */
	public static String getAccessToken() {
		String body = String.format("client_id=%s&client_secret=%s&grant_type=%s", "thiDbBpzzYzOTg4msGZ0IUtyEQgANBhF",
				"REcc6JgnaDavxWPy", "client_credentials");
		Response response = RestAssured.given().with().header("Content-Type", "application/x-www-form-urlencoded")
				.body(body).post("https://qa-apigateway.delta.com/v1/oauth/token");
		// System.out.println(response.asString());
		XmlPath xmlpath = response.xmlPath();
		String access_token = xmlpath.getString("Root.access_token");

		return access_token;

	}

	public static void main(String[] args) {
		System.out.println(Oauth2.getAccessToken());

	}
}
